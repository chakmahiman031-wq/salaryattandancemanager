import React, { useState } from 'react';
import { 
  Settings as SettingsIcon, 
  Globe, 
  Moon, 
  Sun, 
  Monitor, 
  Bell, 
  Download, 
  ShieldCheck, 
  Trash2, 
  Info, 
  Check, 
  AlertTriangle,
  Clock,
  Sparkles,
  Smartphone
} from 'lucide-react';
import { UserSettings, AppLanguage, AppTheme } from '../types';
import { translations } from '../locales/translations';
import { NotificationService } from '../services/notificationService';

interface SettingsScreenProps {
  userSettings: UserSettings;
  onUpdateUserSettings: (settings: Partial<UserSettings>) => void;
  onDownloadAndroidZip: () => void;
  isDownloadingZip: boolean;
  onResetAllData: () => void;
  language: AppLanguage;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  userSettings,
  onUpdateUserSettings,
  onDownloadAndroidZip,
  isDownloadingZip,
  onResetAllData,
  language,
}) => {
  const t = translations[language];

  const [reminderTimeInput, setReminderTimeInput] = useState(userSettings.reminderTime);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [notificationTestStatus, setNotificationTestStatus] = useState<string | null>(null);

  const handleToggleReminder = async (enabled: boolean) => {
    if (enabled) {
      const permission = await NotificationService.requestPermission();
      if (permission === 'denied') {
        alert(t.reminderPermDenied);
      }
    }
    onUpdateUserSettings({ reminderEnabled: enabled });
  };

  const handleTimeChange = (time: string) => {
    setReminderTimeInput(time);
    onUpdateUserSettings({ reminderTime: time });
  };

  const handleTestNotification = async () => {
    const success = await NotificationService.showAttendanceReminder(
      t.reminderTitle,
      t.reminderBody
    );
    if (success) {
      setNotificationTestStatus(t.reminderFired);
      setTimeout(() => setNotificationTestStatus(null), 3000);
    } else {
      setNotificationTestStatus(t.reminderPermDenied);
      setTimeout(() => setNotificationTestStatus(null), 3000);
    }
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      <div>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <SettingsIcon className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
          <span>{t.settingsTitle}</span>
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          {t.settingsSubtitle}
        </p>
      </div>

      {/* 1. Android Project Export Banner */}
      <div className="p-5 rounded-3xl bg-gradient-to-br from-emerald-600 to-teal-800 text-white shadow-md relative overflow-hidden">
        <div className="relative z-10 space-y-3">
          <div className="flex items-center gap-2 text-emerald-100 text-xs font-bold uppercase tracking-wider">
            <Smartphone className="w-4 h-4" />
            <span>{t.downloadAndroidTitle}</span>
          </div>
          <p className="text-xs sm:text-sm text-emerald-50 leading-relaxed max-w-xl">
            {t.downloadAndroidDesc}
          </p>
          <div className="pt-1">
            <button
              id="btn-download-android-zip-settings"
              onClick={onDownloadAndroidZip}
              disabled={isDownloadingZip}
              className="px-4 py-2.5 bg-white text-emerald-900 hover:bg-emerald-50 active:scale-98 text-xs sm:text-sm font-bold rounded-xl shadow-sm transition flex items-center gap-2 disabled:opacity-60"
            >
              <Download className="w-4 h-4 text-emerald-700" />
              <span>{isDownloadingZip ? t.generatingZip : t.downloadAndroidZip}</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Language & Localization Settings */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
          <Globe className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
          <span>{t.language}</span>
        </h3>

        <div className="grid grid-cols-2 gap-3">
          <button
            id="btn-set-lang-bn"
            onClick={() => onUpdateUserSettings({ language: 'bn' })}
            className={`p-3.5 rounded-2xl border text-left transition flex items-center justify-between ${
              userSettings.language === 'bn'
                ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-900 dark:text-emerald-100 font-bold'
                : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200/80 dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            <div>
              <p className="text-sm font-bold">বাংলা (Bengali)</p>
              <p className="text-[11px] text-slate-400">ডিফল্ট ভাষা</p>
            </div>
            {userSettings.language === 'bn' && <Check className="w-4 h-4 text-emerald-600" />}
          </button>

          <button
            id="btn-set-lang-en"
            onClick={() => onUpdateUserSettings({ language: 'en' })}
            className={`p-3.5 rounded-2xl border text-left transition flex items-center justify-between ${
              userSettings.language === 'en'
                ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-900 dark:text-emerald-100 font-bold'
                : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200/80 dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            <div>
              <p className="text-sm font-bold">English</p>
              <p className="text-[11px] text-slate-400">English Language</p>
            </div>
            {userSettings.language === 'en' && <Check className="w-4 h-4 text-emerald-600" />}
          </button>
        </div>
      </div>

      {/* 3. Theme Settings */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
          <Sun className="w-3.5 h-3.5 text-amber-500" />
          <span>{t.theme}</span>
        </h3>

        <div className="grid grid-cols-3 gap-2.5">
          {/* System */}
          <button
            id="btn-theme-system"
            onClick={() => onUpdateUserSettings({ theme: 'system' })}
            className={`p-3 rounded-2xl border text-center transition flex flex-col items-center justify-center gap-1.5 ${
              userSettings.theme === 'system'
                ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-900 dark:text-emerald-100 font-bold'
                : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            <Monitor className="w-4 h-4 text-slate-600 dark:text-slate-400" />
            <span className="text-xs">{t.themeSystem}</span>
          </button>

          {/* Light */}
          <button
            id="btn-theme-light"
            onClick={() => onUpdateUserSettings({ theme: 'light' })}
            className={`p-3 rounded-2xl border text-center transition flex flex-col items-center justify-center gap-1.5 ${
              userSettings.theme === 'light'
                ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-900 dark:text-emerald-100 font-bold'
                : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            <Sun className="w-4 h-4 text-amber-500" />
            <span className="text-xs">{t.themeLight}</span>
          </button>

          {/* Dark */}
          <button
            id="btn-theme-dark"
            onClick={() => onUpdateUserSettings({ theme: 'dark' })}
            className={`p-3 rounded-2xl border text-center transition flex flex-col items-center justify-center gap-1.5 ${
              userSettings.theme === 'dark'
                ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-900 dark:text-emerald-100 font-bold'
                : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            <Moon className="w-4 h-4 text-indigo-400" />
            <span className="text-xs">{t.themeDark}</span>
          </button>
        </div>
      </div>

      {/* 4. Daily Attendance Reminder Settings */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                {t.reminderTitle}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {t.reminderBody}
              </p>
            </div>
          </div>

          {/* Toggle ON / OFF */}
          <button
            id="btn-toggle-reminder"
            onClick={() => handleToggleReminder(!userSettings.reminderEnabled)}
            className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
              userSettings.reminderEnabled ? 'bg-emerald-600' : 'bg-slate-300 dark:bg-slate-700'
            }`}
          >
            <span
              className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                userSettings.reminderEnabled ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {userSettings.reminderEnabled && (
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-400" />
              <label htmlFor="input-reminder-time" className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                {t.reminderTime}:
              </label>
              <input
                id="input-reminder-time"
                type="time"
                value={reminderTimeInput}
                onChange={(e) => handleTimeChange(e.target.value)}
                className="px-2.5 py-1 text-xs font-bold rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>

            <button
              id="btn-test-notification"
              type="button"
              onClick={handleTestNotification}
              className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition"
            >
              {t.testReminder}
            </button>
          </div>
        )}

        {notificationTestStatus && (
          <p className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">
            {notificationTestStatus}
          </p>
        )}
      </div>

      {/* 5. About Application & Privacy */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex items-center gap-3">
          <img
            src="/logo.jpg"
            alt="Logo"
            className="w-12 h-12 rounded-2xl object-cover shadow-sm ring-1 ring-emerald-500/30 shrink-0"
            onError={(e) => {
              (e.target as HTMLElement).style.display = 'none';
            }}
          />
          <div>
            <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
              {t.aboutAppTitle}
            </h3>
            <p className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
              {t.versionLabel}: 1.0.0
            </p>
          </div>
        </div>

        <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
          {t.aboutAppDesc}
        </p>

        {/* Privacy Highlight */}
        <div className="p-3.5 rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-200/60 dark:border-emerald-900/40 flex items-start gap-2.5">
          <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
          <div>
            <p className="text-xs font-bold text-emerald-900 dark:text-emerald-200">
              {t.privacyTitle}
            </p>
            <p className="text-[11px] text-emerald-800 dark:text-emerald-300 mt-0.5 leading-relaxed">
              {t.privacyDesc}
            </p>
          </div>
        </div>
      </div>

      {/* 6. Danger Zone: Reset All Data */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-rose-200 dark:border-rose-950/60 shadow-xs space-y-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-rose-600 dark:text-rose-400 flex items-center gap-1.5">
          <Trash2 className="w-3.5 h-3.5" />
          <span>{t.resetAllData}</span>
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          {language === 'bn' 
            ? 'এটি আপনার সব সংরক্ষিত বেতন সেটিংস ও হাজিরার তথ্য সম্পূর্ণ মুছে ফেলবে।' 
            : 'This permanently wipes all saved monthly settings, daily attendance, and OT records.'}
        </p>

        {!showResetConfirm ? (
          <button
            id="btn-prompt-reset-data"
            onClick={() => setShowResetConfirm(true)}
            className="px-4 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 dark:hover:bg-rose-950/70 border border-rose-200 dark:border-rose-800/60 text-rose-700 dark:text-rose-300 text-xs font-bold transition flex items-center gap-1.5"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>{t.resetAllData}</span>
          </button>
        ) : (
          <div className="p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-800 space-y-2.5 animate-in fade-in duration-150">
            <p className="text-xs font-bold text-rose-800 dark:text-rose-200 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-rose-600" />
              <span>{t.confirmResetTitle}</span>
            </p>
            <p className="text-xs text-rose-700 dark:text-rose-300">
              {t.confirmResetDesc}
            </p>
            <div className="flex items-center gap-2 pt-1">
              <button
                id="btn-confirm-reset-execute"
                onClick={() => {
                  onResetAllData();
                  setShowResetConfirm(false);
                }}
                className="px-4 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-xs transition"
              >
                {t.yesReset}
              </button>
              <button
                onClick={() => setShowResetConfirm(false)}
                className="px-3 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-xl"
              >
                {t.cancel}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
