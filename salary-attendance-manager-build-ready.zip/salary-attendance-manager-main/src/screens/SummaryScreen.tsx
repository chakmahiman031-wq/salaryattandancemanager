import React, { useState } from 'react';
import { 
  FileSpreadsheet, 
  Printer, 
  Copy, 
  Check, 
  Banknote, 
  Calendar, 
  Clock, 
  ShieldCheck, 
  Car, 
  Utensils, 
  Award,
  Sparkles
} from 'lucide-react';
import { SalaryCalculationResult, MonthlySalarySettings, AppLanguage } from '../types';
import { translations } from '../locales/translations';
import { formatCurrency, toBengaliNumerals } from '../services/calculationEngine';

interface SummaryScreenProps {
  year: number;
  month: number;
  calculation: SalaryCalculationResult;
  settings: MonthlySalarySettings;
  language: AppLanguage;
}

export const SummaryScreen: React.FC<SummaryScreenProps> = ({
  year,
  month,
  calculation,
  settings,
  language,
}) => {
  const t = translations[language];
  const [copied, setCopied] = useState(false);

  const monthName = t.monthNames[month - 1];
  const displayYear = language === 'bn' ? toBengaliNumerals(year) : year;

  const formatNum = (num: number) => {
    return language === 'bn' ? toBengaliNumerals(num) : num;
  };

  const formatMoney = (amount: number) => {
    const formatted = formatCurrency(amount, '৳');
    return language === 'bn' ? toBengaliNumerals(formatted) : formatted;
  };

  const handlePrint = () => {
    window.print();
  };

  const handleCopyTextSummary = () => {
    const text = `
=== ${t.appName} - ${monthName} ${displayYear} ===
${t.netPayable}: ${formatCurrency(calculation.finalExpectedSalary, '৳')}

-- ${t.attendanceOverview} --
${t.workingDays}: ${calculation.workingDays}
${t.statusPresent}: ${calculation.presentDays}
${t.statusAbsent}: ${calculation.absentDays}
${t.statusLeave}: ${calculation.leaveDays}
${t.statusNotMarked}: ${calculation.notMarkedDays}

-- ${t.salaryBreakdown} --
${t.basicSalary}: ${formatCurrency(calculation.basicSalary, '৳')}
${t.absentDeduction}: -${formatCurrency(calculation.basicDeduction, '৳')}
${t.earnedSalary} (${t.basicSalary}): ${formatCurrency(calculation.basicEarnedSalary, '৳')}

${t.transportAllowance}: ${formatCurrency(calculation.transportEarned, '৳')} (Deduction: -${formatCurrency(calculation.transportDeduction, '৳')})
${t.foodAllowance}: ${formatCurrency(calculation.foodEarned, '৳')} (Deduction: -${formatCurrency(calculation.foodDeduction, '৳')})
${t.attendanceBonus}: ${formatCurrency(calculation.attendanceBonus, '৳')}

-- ${t.otSummary} --
${t.totalOtHours}: ${calculation.totalOtHours} hrs
${t.otRate}: ${formatCurrency(calculation.otRate, '৳')}/hr
${t.totalOtPay}: ${formatCurrency(calculation.otPay, '৳')}

=======================================
${t.netPayable}: ${formatCurrency(calculation.finalExpectedSalary, '৳')}
    `.trim();

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="space-y-5 pb-8 animate-in fade-in duration-200">
      {/* Header with Print & Copy Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            <span>{t.summaryTitle}</span>
          </h2>
          <p className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 mt-0.5">
            {monthName} {displayYear}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="btn-copy-summary-text"
            onClick={handleCopyTextSummary}
            className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-semibold hover:bg-slate-50 dark:hover:bg-slate-750 transition flex items-center gap-1.5 shadow-xs"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? (language === 'bn' ? 'কপি হয়েছে' : 'Copied!') : (language === 'bn' ? 'কপি করুন' : 'Copy')}</span>
          </button>

          <button
            id="btn-print-summary"
            onClick={handlePrint}
            className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'প্রিন্ট' : 'Print'}</span>
          </button>
        </div>
      </div>

      {/* Net Payable Highlight Card */}
      <div className="rounded-3xl bg-gradient-to-br from-emerald-600 to-teal-800 text-white p-6 shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-100 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>{t.netPayable}</span>
            </span>
            <div className="text-3xl sm:text-5xl font-extrabold tracking-tight mt-1">
              {formatMoney(calculation.finalExpectedSalary)}
            </div>
            <p className="text-xs text-emerald-100 mt-2">
              {language === 'bn'
                ? `মূল অর্জিত (${formatMoney(calculation.basicEarnedSalary)}) + যাতায়াত (${formatMoney(calculation.transportEarned)}) + খাদ্য (${formatMoney(calculation.foodEarned)}) + বোনাস (${formatMoney(calculation.attendanceBonus)}) + ওভারটাইম (${formatMoney(calculation.otPay)})`
                : `Basic Earned (${formatMoney(calculation.basicEarnedSalary)}) + Transport (${formatMoney(calculation.transportEarned)}) + Food (${formatMoney(calculation.foodEarned)}) + Bonus (${formatMoney(calculation.attendanceBonus)}) + OT (${formatMoney(calculation.otPay)})`}
            </p>
          </div>
        </div>
      </div>

      {/* Attendance Summary Section */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
          <Calendar className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
          <span>{t.attendanceOverview}</span>
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60">
            <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">{t.workingDays}</p>
            <p className="text-lg font-bold text-slate-800 dark:text-slate-100">{formatNum(calculation.workingDays)}</p>
          </div>
          <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200/60 dark:border-emerald-800/60">
            <p className="text-xs text-emerald-700 dark:text-emerald-400 font-medium">{t.statusPresent}</p>
            <p className="text-lg font-bold text-emerald-900 dark:text-emerald-100">{formatNum(calculation.presentDays)}</p>
          </div>
          <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200/60 dark:border-rose-800/60">
            <p className="text-xs text-rose-700 dark:text-rose-400 font-medium">{t.statusAbsent}</p>
            <p className="text-lg font-bold text-rose-900 dark:text-rose-100">{formatNum(calculation.absentDays)}</p>
          </div>
          <div className="p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200/60 dark:border-amber-800/60">
            <p className="text-xs text-amber-700 dark:text-amber-400 font-medium">{t.statusLeave}</p>
            <p className="text-lg font-bold text-amber-900 dark:text-amber-100">{formatNum(calculation.leaveDays)}</p>
          </div>
          <div className="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60 col-span-2 sm:col-span-1">
            <p className="text-xs text-slate-600 dark:text-slate-400 font-medium">{t.statusNotMarked}</p>
            <p className="text-lg font-bold text-slate-800 dark:text-slate-100">{formatNum(calculation.notMarkedDays)}</p>
          </div>
        </div>
      </div>

      {/* Detailed Salary & Deduction Breakdown Table */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
          <Banknote className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
          <span>{t.salaryBreakdown}</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                <th className="pb-2.5 font-bold uppercase tracking-wider">{language === 'bn' ? 'খাত' : 'Component'}</th>
                <th className="pb-2.5 font-bold uppercase tracking-wider">{language === 'bn' ? 'নির্ধারিত' : 'Configured'}</th>
                <th className="pb-2.5 font-bold uppercase tracking-wider">{language === 'bn' ? 'কর্তন' : 'Deduction'}</th>
                <th className="pb-2.5 font-bold uppercase tracking-wider text-right">{language === 'bn' ? 'চূড়ান্ত অর্জিত' : 'Earned'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {/* Basic Salary */}
              <tr>
                <td className="py-3 font-semibold text-slate-800 dark:text-slate-200">
                  {t.basicSalary}
                  <span className="block text-[11px] text-slate-400 font-normal">
                    {formatMoney(calculation.dailyBasicSalary)}/{language === 'bn' ? 'দিন' : 'day'}
                  </span>
                </td>
                <td className="py-3 font-medium text-slate-600 dark:text-slate-300">
                  {formatMoney(calculation.basicSalary)}
                </td>
                <td className="py-3 font-semibold text-rose-600 dark:text-rose-400">
                  {calculation.basicDeduction > 0 ? `-${formatMoney(calculation.basicDeduction)}` : '৳0'}
                </td>
                <td className="py-3 font-bold text-slate-900 dark:text-white text-right">
                  {formatMoney(calculation.basicEarnedSalary)}
                </td>
              </tr>

              {/* Transport Allowance */}
              <tr>
                <td className="py-3 font-semibold text-slate-800 dark:text-slate-200">
                  {t.transportAllowance}
                  <span className="block text-[11px] text-slate-400 font-normal">
                    {settings.deductTransportOnAbsent ? (language === 'bn' ? 'অনুপস্থিতিতে কর্তন প্রযোজ্য' : 'Absent deduction enabled') : (language === 'bn' ? 'নির্দিষ্ট (কর্তনমুক্ত)' : 'Fixed')}
                  </span>
                </td>
                <td className="py-3 font-medium text-slate-600 dark:text-slate-300">
                  {formatMoney(calculation.transportAllowance)}
                </td>
                <td className="py-3 font-semibold text-rose-600 dark:text-rose-400">
                  {calculation.transportDeduction > 0 ? `-${formatMoney(calculation.transportDeduction)}` : '৳0'}
                </td>
                <td className="py-3 font-bold text-slate-900 dark:text-white text-right">
                  {formatMoney(calculation.transportEarned)}
                </td>
              </tr>

              {/* Food Allowance */}
              <tr>
                <td className="py-3 font-semibold text-slate-800 dark:text-slate-200">
                  {t.foodAllowance}
                  <span className="block text-[11px] text-slate-400 font-normal">
                    {settings.deductFoodOnAbsent ? (language === 'bn' ? 'অনুপস্থিতিতে কর্তন প্রযোজ্য' : 'Absent deduction enabled') : (language === 'bn' ? 'নির্দিষ্ট (কর্তনমুক্ত)' : 'Fixed')}
                  </span>
                </td>
                <td className="py-3 font-medium text-slate-600 dark:text-slate-300">
                  {formatMoney(calculation.foodAllowance)}
                </td>
                <td className="py-3 font-semibold text-rose-600 dark:text-rose-400">
                  {calculation.foodDeduction > 0 ? `-${formatMoney(calculation.foodDeduction)}` : '৳0'}
                </td>
                <td className="py-3 font-bold text-slate-900 dark:text-white text-right">
                  {formatMoney(calculation.foodEarned)}
                </td>
              </tr>

              {/* Attendance Bonus */}
              <tr>
                <td className="py-3 font-semibold text-slate-800 dark:text-slate-200">
                  {t.attendanceBonus}
                  <span className="block text-[11px] text-slate-400 font-normal">
                    {calculation.attendanceBonus > 0 ? t.fullBonusEarned : (calculation.bonusForfeitedReason === 'LEAVE_DAYS' ? t.bonusLostLeave : t.bonusLostAbsent)}
                  </span>
                </td>
                <td className="py-3 font-medium text-slate-600 dark:text-slate-300">
                  {formatMoney(calculation.attendanceBonusConfig)}
                </td>
                <td className="py-3 font-semibold text-rose-600 dark:text-rose-400">
                  {calculation.attendanceBonus === 0 && calculation.attendanceBonusConfig > 0 ? `-${formatMoney(calculation.attendanceBonusConfig)}` : '৳0'}
                </td>
                <td className="py-3 font-bold text-slate-900 dark:text-white text-right">
                  {formatMoney(calculation.attendanceBonus)}
                </td>
              </tr>

              {/* Overtime (OT) */}
              <tr>
                <td className="py-3 font-semibold text-slate-800 dark:text-slate-200">
                  {t.otSummary}
                  <span className="block text-[11px] text-slate-400 font-normal">
                    {formatNum(calculation.totalOtHours)} {t.hoursShort} @ {formatMoney(calculation.otRate)}/{t.hoursShort}
                  </span>
                </td>
                <td className="py-3 font-medium text-slate-600 dark:text-slate-300">
                  -
                </td>
                <td className="py-3 font-medium text-slate-400">
                  -
                </td>
                <td className="py-3 font-bold text-teal-600 dark:text-teal-400 text-right">
                  +{formatMoney(calculation.otPay)}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
