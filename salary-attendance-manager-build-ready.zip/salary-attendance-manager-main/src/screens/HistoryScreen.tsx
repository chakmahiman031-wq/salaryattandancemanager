import React from 'react';
import { History, ChevronRight, Calendar, Banknote, CheckCircle2, XCircle, ArrowRight } from 'lucide-react';
import { MonthlySalarySettings, AppLanguage } from '../types';
import { translations } from '../locales/translations';
import { calculateMonthlySalary, formatCurrency, toBengaliNumerals } from '../services/calculationEngine';
import { StorageService } from '../services/storageService';

interface HistoryScreenProps {
  onSelectMonth: (year: number, month: number) => void;
  language: AppLanguage;
}

export const HistoryScreen: React.FC<HistoryScreenProps> = ({
  onSelectMonth,
  language,
}) => {
  const t = translations[language];

  // Retrieve all monthly settings
  const allSettings = StorageService.getAllMonthlySettings();

  // Sort months descending (most recent first)
  const sortedSettings = [...allSettings].sort((a, b) => {
    if (a.year !== b.year) return b.year - a.year;
    return b.month - a.month;
  });

  const formatMoney = (amount: number) => {
    const formatted = formatCurrency(amount, '৳');
    return language === 'bn' ? toBengaliNumerals(formatted) : formatted;
  };

  const formatNum = (num: number) => {
    return language === 'bn' ? toBengaliNumerals(num) : num;
  };

  return (
    <div className="space-y-4 pb-8 animate-in fade-in duration-200">
      <div>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <History className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
          <span>{t.historyTitle}</span>
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          {t.historySubtitle}
        </p>
      </div>

      {sortedSettings.length === 0 ? (
        <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <Calendar className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto mb-2" />
          <p className="text-sm font-semibold text-slate-600 dark:text-slate-300">
            {t.noHistory}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {sortedSettings.map((setting) => {
            const attendance = StorageService.getAttendanceForMonth(setting.year, setting.month);
            const otRecords = StorageService.getDailyOtForMonth(setting.year, setting.month);
            const calculation = calculateMonthlySalary(setting, attendance, otRecords);

            const monthName = t.monthNames[setting.month - 1];
            const displayYear = language === 'bn' ? toBengaliNumerals(setting.year) : setting.year;

            return (
              <button
                key={setting.id}
                id={`btn-history-item-${setting.year}-${setting.month}`}
                onClick={() => onSelectMonth(setting.year, setting.month)}
                className="w-full text-left p-4 rounded-2xl bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800/80 border border-slate-200/80 dark:border-slate-800 shadow-xs transition-all duration-150 active:scale-99 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 group"
              >
                {/* Left info: Month & Year */}
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-extrabold text-base text-slate-900 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                      {monthName} {displayYear}
                    </h3>
                  </div>

                  {/* Attendance chips */}
                  <div className="flex items-center gap-2.5 mt-2 text-xs">
                    <span className="inline-flex items-center gap-1 font-semibold text-emerald-700 dark:text-emerald-400">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{formatNum(calculation.presentDays)} {t.statsPresent}</span>
                    </span>
                    <span className="text-slate-300 dark:text-slate-700">•</span>
                    <span className="inline-flex items-center gap-1 font-semibold text-rose-700 dark:text-rose-400">
                      <XCircle className="w-3.5 h-3.5" />
                      <span>{formatNum(calculation.absentDays)} {t.statsAbsent}</span>
                    </span>
                    {calculation.totalOtHours > 0 && (
                      <>
                        <span className="text-slate-300 dark:text-slate-700">•</span>
                        <span className="font-semibold text-teal-600 dark:text-teal-400">
                          +{formatNum(calculation.totalOtHours)}h OT
                        </span>
                      </>
                    )}
                  </div>
                </div>

                {/* Right info: Salary Amount & Arrow */}
                <div className="flex items-center justify-between sm:justify-end gap-3 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100 dark:border-slate-800">
                  <div className="text-left sm:text-right">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                      {t.expectedSalary}
                    </span>
                    <span className="text-lg font-extrabold text-slate-900 dark:text-white">
                      {formatMoney(calculation.finalExpectedSalary)}
                    </span>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-400 group-hover:bg-emerald-100 dark:group-hover:bg-emerald-950 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 flex items-center justify-center transition-colors shrink-0">
                    <ChevronRight className="w-4 h-4" />
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};
