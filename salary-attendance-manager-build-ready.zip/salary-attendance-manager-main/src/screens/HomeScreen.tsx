import React from 'react';
import { 
  Banknote, 
  TrendingUp, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  AlertTriangle, 
  Settings2, 
  Copy, 
  CalendarDays,
  Sparkles,
  Info
} from 'lucide-react';
import { 
  SalaryCalculationResult, 
  MonthlySalarySettings, 
  AppLanguage 
} from '../types';
import { translations } from '../locales/translations';
import { 
  formatCurrency, 
  toBengaliNumerals 
} from '../services/calculationEngine';

interface HomeScreenProps {
  year: number;
  month: number;
  calculation: SalaryCalculationResult;
  settings: MonthlySalarySettings;
  onOpenDailyModalForDate: (date: number) => void;
  onOpenMonthlySettings: () => void;
  onCopyPreviousMonth: () => boolean;
  onNavigateToCalendar: () => void;
  language: AppLanguage;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  year,
  month,
  calculation,
  settings,
  onOpenDailyModalForDate,
  onOpenMonthlySettings,
  onCopyPreviousMonth,
  onNavigateToCalendar,
  language,
}) => {
  const t = translations[language];

  const now = new Date();
  const isCurrentMonth = now.getFullYear() === year && (now.getMonth() + 1) === month;
  const todayDate = isCurrentMonth ? now.getDate() : 1;

  const monthName = t.monthNames[month - 1];
  const displayYear = language === 'bn' ? toBengaliNumerals(year) : year;

  const formatNum = (num: number) => {
    return language === 'bn' ? toBengaliNumerals(num) : num;
  };

  const formatMoney = (amount: number) => {
    const formatted = formatCurrency(amount, '৳');
    return language === 'bn' ? toBengaliNumerals(formatted) : formatted;
  };

  return (
    <div className="space-y-5 pb-8 animate-in fade-in duration-200">
      {/* Top Banner: Selected Month & Quick Config */}
      <div className="flex items-center justify-between gap-3">
        <div>
          <span className="text-[11px] font-bold tracking-wider uppercase text-emerald-600 dark:text-emerald-400">
            {language === 'bn' ? 'চলতি নির্বাচিত মাস' : 'Selected Payroll Month'}
          </span>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
            {monthName} {displayYear}
          </h2>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="btn-quick-config-month"
            onClick={onOpenMonthlySettings}
            className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-750 text-xs font-semibold shadow-xs flex items-center gap-1.5 transition"
            title={t.configureMonth}
          >
            <Settings2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span className="hidden xs:inline">{t.configureMonth}</span>
          </button>
        </div>
      </div>

      {/* Unmarked Days Warning Banner */}
      {calculation.notMarkedDays > 0 && (
        <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 flex items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-2.5">
            <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0" />
            <p className="text-xs sm:text-sm font-semibold text-amber-900 dark:text-amber-200">
              {t.unmarkedWarning.replace(
                '{count}',
                String(formatNum(calculation.notMarkedDays))
              )}
            </p>
          </div>
          <button
            id="btn-goto-calendar-from-warning"
            onClick={onNavigateToCalendar}
            className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shrink-0 transition"
          >
            {t.navCalendar}
          </button>
        </div>
      )}

      {/* Hero Card: EXPECTED SALARY (Material 3 Card) */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-600 via-emerald-700 to-teal-800 text-white shadow-lg p-6 sm:p-7">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-800/70 border border-emerald-400/30 text-emerald-100 text-xs font-bold mb-2">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>{t.expectedSalary}</span>
            </div>
            <div className="text-3xl sm:text-5xl font-extrabold tracking-tight">
              {formatMoney(calculation.finalExpectedSalary)}
            </div>
            <p className="text-xs text-emerald-100 mt-2 flex items-center gap-1">
              <Info className="w-3.5 h-3.5 shrink-0 opacity-80" />
              <span>
                {language === 'bn'
                  ? `কর্মদিবস: ${formatNum(calculation.workingDays)} দিন | প্রতি দিন মূল হার: ${formatMoney(calculation.dailyBasicSalary)}`
                  : `Working Days: ${formatNum(calculation.workingDays)} days | Daily Basic: ${formatMoney(calculation.dailyBasicSalary)}`}
              </span>
            </p>
          </div>

          {/* Quick Action: Mark Today */}
          <div className="shrink-0 flex flex-col sm:flex-row gap-2">
            <button
              id="btn-mark-today-attendance"
              onClick={() => onOpenDailyModalForDate(todayDate)}
              className="px-4 py-2.5 rounded-xl bg-white text-emerald-800 hover:bg-emerald-50 active:scale-98 font-bold text-xs sm:text-sm shadow-md transition flex items-center justify-center gap-2"
            >
              <CalendarDays className="w-4 h-4 text-emerald-600" />
              <span>{t.markToday} ({formatNum(todayDate)} {monthName})</span>
            </button>
          </div>
        </div>

        {/* Decorative ambient rings */}
        <div className="absolute -right-8 -bottom-10 w-44 h-44 rounded-full bg-white/5 pointer-events-none" />
        <div className="absolute right-14 -top-12 w-32 h-32 rounded-full bg-emerald-400/10 pointer-events-none" />
      </div>

      {/* Attendance Stats Counter Badges */}
      <div>
        <div className="flex items-center justify-between mb-2.5">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            {t.attendanceOverview}
          </h3>
          <span className="text-xs text-slate-400">
            {language === 'bn' 
              ? `মোট দিন: ${formatNum(calculation.totalDaysInMonth)}` 
              : `Total days: ${formatNum(calculation.totalDaysInMonth)}`}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
          {/* Present */}
          <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200/80 dark:border-emerald-800/50 flex items-center justify-between">
            <div>
              <p className="text-[11px] font-bold text-emerald-700 dark:text-emerald-400">
                {t.statsPresent}
              </p>
              <p className="text-xl font-extrabold text-emerald-900 dark:text-emerald-100">
                {formatNum(calculation.presentDays)}
              </p>
            </div>
            <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>

          {/* Absent */}
          <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200/80 dark:border-rose-800/50 flex items-center justify-between">
            <div>
              <p className="text-[11px] font-bold text-rose-700 dark:text-rose-400">
                {t.statsAbsent}
              </p>
              <p className="text-xl font-extrabold text-rose-900 dark:text-rose-100">
                {formatNum(calculation.absentDays)}
              </p>
            </div>
            <div className="w-8 h-8 rounded-full bg-rose-500/20 text-rose-600 dark:text-rose-400 flex items-center justify-center">
              <XCircle className="w-4 h-4" />
            </div>
          </div>

          {/* Leave */}
          <div className="p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-800/50 flex items-center justify-between">
            <div>
              <p className="text-[11px] font-bold text-amber-700 dark:text-amber-400">
                {t.statsLeave}
              </p>
              <p className="text-xl font-extrabold text-amber-900 dark:text-amber-100">
                {formatNum(calculation.leaveDays)}
              </p>
            </div>
            <div className="w-8 h-8 rounded-full bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>

          {/* Not Marked */}
          <div className="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 flex items-center justify-between">
            <div>
              <p className="text-[11px] font-bold text-slate-600 dark:text-slate-400">
                {t.statsNotMarked}
              </p>
              <p className="text-xl font-extrabold text-slate-800 dark:text-slate-100">
                {formatNum(calculation.notMarkedDays)}
              </p>
            </div>
            <div className="w-8 h-8 rounded-full bg-slate-400/20 text-slate-500 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>

          {/* OT Hours */}
          <div className="p-3 rounded-2xl bg-teal-50 dark:bg-teal-950/30 border border-teal-200/80 dark:border-teal-800/50 flex items-center justify-between col-span-2 sm:col-span-1">
            <div>
              <p className="text-[11px] font-bold text-teal-700 dark:text-teal-400">
                {t.statsOtHours}
              </p>
              <p className="text-xl font-extrabold text-teal-900 dark:text-teal-100">
                {formatNum(calculation.totalOtHours)} {t.hoursShort}
              </p>
            </div>
            <div className="w-8 h-8 rounded-full bg-teal-500/20 text-teal-600 dark:text-teal-400 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
        </div>
      </div>

      {/* Salary Breakdown Section */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Banknote className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>{t.breakdown}</span>
          </h3>
          <span className="text-xs text-slate-400 font-medium">
            {monthName} {displayYear}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {/* Basic Salary */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/60">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                {t.basicSalary}
              </span>
              <span className="text-sm font-bold text-slate-800 dark:text-slate-100">
                {formatMoney(calculation.basicEarnedSalary)}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              {language === 'bn' ? 'মূল চুক্তি:' : 'Configured:'} {formatMoney(calculation.basicSalary)}
            </p>
          </div>

          {/* Transport Allowance */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/60">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                {t.transportAllowance}
              </span>
              <span className="text-sm font-bold text-slate-800 dark:text-slate-100">
                {formatMoney(calculation.transportEarned)}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              {settings.deductTransportOnAbsent
                ? (calculation.transportDeduction > 0 
                    ? `${language === 'bn' ? 'কর্তন:' : 'Deducted:'} -${formatMoney(calculation.transportDeduction)}`
                    : (language === 'bn' ? 'কর্তন প্রযোজ্য (০ অনুপস্থিত)' : 'Deductible (0 absent)'))
                : (language === 'bn' ? 'কর্তনমুক্ত (নির্দিষ্ট)' : 'Fixed')}
            </p>
          </div>

          {/* Food Allowance */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/60">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                {t.foodAllowance}
              </span>
              <span className="text-sm font-bold text-slate-800 dark:text-slate-100">
                {formatMoney(calculation.foodEarned)}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              {settings.deductFoodOnAbsent
                ? (calculation.foodDeduction > 0 
                    ? `${language === 'bn' ? 'কর্তন:' : 'Deducted:'} -${formatMoney(calculation.foodDeduction)}`
                    : (language === 'bn' ? 'কর্তন প্রযোজ্য (০ অনুপস্থিত)' : 'Deductible (0 absent)'))
                : (language === 'bn' ? 'কর্তনমুক্ত (নির্দিষ্ট)' : 'Fixed')}
            </p>
          </div>

          {/* Attendance Bonus */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/60">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                {t.attendanceBonus}
              </span>
              <span className={`text-sm font-bold ${
                calculation.attendanceBonus > 0 
                  ? 'text-emerald-600 dark:text-emerald-400' 
                  : 'text-slate-400'
              }`}>
                {formatMoney(calculation.attendanceBonus)}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              {calculation.attendanceBonus > 0
                ? t.fullBonusEarned
                : (calculation.bonusForfeitedReason === 'LEAVE_DAYS' 
                    ? t.bonusLostLeave 
                    : t.bonusLostAbsent)}
            </p>
          </div>

          {/* Overtime (OT) Pay */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/60">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                {t.otPay}
              </span>
              <span className="text-sm font-bold text-teal-600 dark:text-teal-400">
                +{formatMoney(calculation.otPay)}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              {formatNum(calculation.totalOtHours)} {t.hoursShort} × {formatMoney(calculation.otRate)}
            </p>
          </div>

          {/* Absent Deduction */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/60">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                {t.absentDeduction}
              </span>
              <span className={`text-sm font-bold ${
                calculation.basicDeduction > 0 
                  ? 'text-rose-600 dark:text-rose-400' 
                  : 'text-slate-400'
              }`}>
                -{formatMoney(calculation.basicDeduction)}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              {formatNum(calculation.absentDays)} {language === 'bn' ? 'অনুপস্থিত দিন' : 'absent day(s)'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
