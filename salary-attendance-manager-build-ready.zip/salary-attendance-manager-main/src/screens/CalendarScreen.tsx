import React from 'react';
import { Clock, CheckCircle2, XCircle, AlertTriangle, HelpCircle } from 'lucide-react';
import { AttendanceRecord, DailyOTRecord, AppLanguage, AttendanceStatus } from '../types';
import { translations } from '../locales/translations';
import { getDaysInMonth, toBengaliNumerals } from '../services/calculationEngine';

interface CalendarScreenProps {
  year: number;
  month: number;
  attendanceRecords: AttendanceRecord[];
  otRecords: DailyOTRecord[];
  onDateClick: (date: number) => void;
  language: AppLanguage;
}

export const CalendarScreen: React.FC<CalendarScreenProps> = ({
  year,
  month,
  attendanceRecords,
  otRecords,
  onDateClick,
  language,
}) => {
  const t = translations[language];

  const totalDays = getDaysInMonth(year, month);
  const monthName = t.monthNames[month - 1];
  const displayYear = language === 'bn' ? toBengaliNumerals(year) : year;

  // First day of month weekday (0 = Sunday, 1 = Monday, etc.)
  const firstDayWeekday = new Date(year, month - 1, 1).getDay();

  // Maps for quick lookup
  const attendanceMap = new Map<number, AttendanceStatus>();
  for (const record of attendanceRecords) {
    attendanceMap.set(record.date, record.status);
  }

  const otMap = new Map<number, number>();
  for (const ot of otRecords) {
    if (ot.otHours > 0) {
      otMap.set(ot.date, ot.otHours);
    }
  }

  const now = new Date();
  const isCurrentActualMonth = now.getFullYear() === year && (now.getMonth() + 1) === month;
  const currentActualDate = now.getDate();

  // Create array of day slots: empty slots before day 1, followed by 1..totalDays
  const calendarCells: (number | null)[] = [];
  for (let i = 0; i < firstDayWeekday; i++) {
    calendarCells.push(null);
  }
  for (let d = 1; d <= totalDays; d++) {
    calendarCells.push(d);
  }

  return (
    <div className="space-y-4 pb-8 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">
            {t.calendarTitle}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            {t.tapToMark}
          </p>
        </div>
        <div className="px-3 py-1 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 font-bold text-xs rounded-xl">
          {monthName} {displayYear}
        </div>
      </div>

      {/* Legend */}
      <div className="flex flex-wrap items-center gap-3 p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs text-xs">
        <div className="flex items-center gap-1.5 font-medium text-slate-700 dark:text-slate-300">
          <div className="w-3 h-3 rounded-full bg-emerald-500 shadow-xs" />
          <span>{t.statusPresent}</span>
        </div>
        <div className="flex items-center gap-1.5 font-medium text-slate-700 dark:text-slate-300">
          <div className="w-3 h-3 rounded-full bg-rose-500 shadow-xs" />
          <span>{t.statusAbsent}</span>
        </div>
        <div className="flex items-center gap-1.5 font-medium text-slate-700 dark:text-slate-300">
          <div className="w-3 h-3 rounded-full bg-amber-500 shadow-xs" />
          <span>{t.statusLeave}</span>
        </div>
        <div className="flex items-center gap-1.5 font-medium text-slate-700 dark:text-slate-300">
          <div className="w-3 h-3 rounded-full bg-slate-300 dark:bg-slate-600 shadow-xs" />
          <span>{t.statusNotMarked}</span>
        </div>
      </div>

      {/* Calendar Grid Container */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-3 sm:p-5 border border-slate-200 dark:border-slate-800 shadow-xs">
        {/* Weekday Headers */}
        <div className="grid grid-cols-7 gap-1 sm:gap-2 mb-2">
          {t.dayNames.map((day, idx) => (
            <div
              key={idx}
              className={`text-center py-2 text-xs font-bold ${
                idx === 5 ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              {day}
            </div>
          ))}
        </div>

        {/* Days Grid */}
        <div className="grid grid-cols-7 gap-1 sm:gap-2">
          {calendarCells.map((day, idx) => {
            if (day === null) {
              return (
                <div
                  key={`empty-${idx}`}
                  className="aspect-square rounded-2xl bg-slate-50/50 dark:bg-slate-950/20 border border-transparent"
                />
              );
            }

            const status = attendanceMap.get(day) || 'NOT_MARKED';
            const otHours = otMap.get(day);
            const isToday = isCurrentActualMonth && day === currentActualDate;

            // Status Styling
            let bgClass = 'bg-slate-50 dark:bg-slate-800/60 border-slate-200/70 dark:border-slate-700/60 text-slate-700 dark:text-slate-200';
            let indicatorBg = 'bg-slate-300 dark:bg-slate-600';
            let statusText = t.statusNotMarked;

            if (status === 'PRESENT') {
              bgClass = 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-100 shadow-xs';
              indicatorBg = 'bg-emerald-500';
              statusText = t.statusPresent;
            } else if (status === 'ABSENT') {
              bgClass = 'bg-rose-50 dark:bg-rose-950/40 border-rose-300 dark:border-rose-800 text-rose-900 dark:text-rose-100 shadow-xs';
              indicatorBg = 'bg-rose-500';
              statusText = t.statusAbsent;
            } else if (status === 'LEAVE') {
              bgClass = 'bg-amber-50 dark:bg-amber-950/40 border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-100 shadow-xs';
              indicatorBg = 'bg-amber-500';
              statusText = t.statusLeave;
            }

            const displayDay = language === 'bn' ? toBengaliNumerals(day) : day;

            return (
              <button
                key={`day-${day}`}
                id={`cal-day-cell-${day}`}
                onClick={() => onDateClick(day)}
                className={`group relative aspect-square rounded-2xl border p-1 sm:p-2 flex flex-col justify-between transition-all duration-150 active:scale-95 hover:border-emerald-500/80 focus:outline-none focus:ring-2 focus:ring-emerald-500/40 ${bgClass} ${
                  isToday ? 'ring-2 ring-emerald-500' : ''
                }`}
              >
                {/* Top Row: Date number & Today dot */}
                <div className="w-full flex items-center justify-between">
                  <span className="text-xs sm:text-sm font-extrabold leading-none">
                    {displayDay}
                  </span>
                  {isToday && (
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 dark:bg-emerald-400" title="Today" />
                  )}
                </div>

                {/* Center / Status Indicator */}
                <div className="w-full flex items-center justify-center my-auto">
                  <div className={`w-2.5 h-2.5 sm:w-3 sm:h-3 rounded-full ${indicatorBg} shadow-xs`} />
                </div>

                {/* Bottom Row: OT Badge if present */}
                <div className="w-full truncate text-[10px] sm:text-[11px] font-bold text-center">
                  {otHours && otHours > 0 ? (
                    <span className="inline-block px-1 py-0.2 rounded bg-teal-600/15 text-teal-700 dark:text-teal-300 truncate max-w-full">
                      +{language === 'bn' ? toBengaliNumerals(otHours) : otHours}h
                    </span>
                  ) : (
                    <span className="hidden sm:inline text-[9px] text-slate-400 font-normal">
                      {status === 'PRESENT' ? 'P' : status === 'ABSENT' ? 'A' : status === 'LEAVE' ? 'L' : '-'}
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
