import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { 
  NavigationTab, 
  AppLanguage, 
  AppTheme, 
  MonthlySalarySettings, 
  AttendanceRecord, 
  DailyOTRecord, 
  AttendanceStatus,
  UserSettings 
} from './types';
import { StorageService } from './services/storageService';
import { calculateMonthlySalary, getDaysInMonth } from './services/calculationEngine';
import { NotificationService } from './services/notificationService';
import { downloadAndroidProjectZip } from './services/androidProjectGenerator';
import { translations } from './locales/translations';

// Components
import { Navbar } from './components/Navbar';
import { BottomNav } from './components/BottomNav';
import { DailyAttendanceModal } from './components/DailyAttendanceModal';
import { MonthlySettingsModal } from './components/MonthlySettingsModal';
import { MonthPickerModal } from './components/MonthPickerModal';
import { FirstTimeSetupModal } from './components/FirstTimeSetupModal';

// Screens
import { HomeScreen } from './screens/HomeScreen';
import { CalendarScreen } from './screens/CalendarScreen';
import { SummaryScreen } from './screens/SummaryScreen';
import { HistoryScreen } from './screens/HistoryScreen';
import { SettingsScreen } from './screens/SettingsScreen';

export default function App() {
  // 1. Current Selected Date & Year (Default to September 2026 or current)
  const [selectedYear, setSelectedYear] = useState<number>(2026);
  const [selectedMonth, setSelectedMonth] = useState<number>(9);

  // 2. Active Tab
  const [activeTab, setActiveTab] = useState<NavigationTab>('home');

  // 3. User Settings & First Time Setup State
  const [userSettings, setUserSettings] = useState<UserSettings>(() => StorageService.getUserSettings());
  const [showFirstTimeSetup, setShowFirstTimeSetup] = useState<boolean>(!userSettings.isFirstTimeSetupCompleted);

  // 4. Monthly State
  const [monthlySettings, setMonthlySettings] = useState<MonthlySalarySettings>(() => {
    return (
      StorageService.getMonthlySettings(2026, 9) || {
        id: 'settings_2026_9',
        year: 2026,
        month: 9,
        basicSalary: 20000,
        transportAllowance: 3000,
        foodAllowance: 2000,
        attendanceBonus: 2000,
        workingDays: 26,
        otRate: 100,
        deductTransportOnAbsent: false,
        deductFoodOnAbsent: false,
        leaveAffectsBonus: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }
    );
  });

  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>(() => {
    return StorageService.getAttendanceForMonth(2026, 9);
  });

  const [otRecords, setOtRecords] = useState<DailyOTRecord[]>(() => {
    return StorageService.getDailyOtForMonth(2026, 9);
  });

  // 5. Modals State
  const [dailyModalState, setDailyModalState] = useState<{
    isOpen: boolean;
    date: number;
    status: AttendanceStatus;
    otHours: number;
  }>({
    isOpen: false,
    date: 1,
    status: 'NOT_MARKED',
    otHours: 0,
  });

  const [isMonthlySettingsModalOpen, setIsMonthlySettingsModalOpen] = useState<boolean>(false);
  const [isMonthPickerModalOpen, setIsMonthPickerModalOpen] = useState<boolean>(false);
  const [isDownloadingZip, setIsDownloadingZip] = useState<boolean>(false);

  // 6. Reload Month Data when Year or Month Changes
  const reloadMonthData = useCallback((year: number, month: number) => {
    let settings = StorageService.getMonthlySettings(year, month);
    if (!settings) {
      // Find latest previous settings to inherit defaults from
      const all = StorageService.getAllMonthlySettings();
      const prev = all.find((s) => s.year < year || (s.year === year && s.month < month));

      settings = {
        id: `settings_${year}_${month}`,
        year,
        month,
        basicSalary: prev ? prev.basicSalary : 20000,
        transportAllowance: prev ? prev.transportAllowance : 3000,
        foodAllowance: prev ? prev.foodAllowance : 2000,
        attendanceBonus: prev ? prev.attendanceBonus : 2000,
        workingDays: prev ? prev.workingDays : 26,
        otRate: prev ? prev.otRate : 100,
        deductTransportOnAbsent: prev ? prev.deductTransportOnAbsent : false,
        deductFoodOnAbsent: prev ? prev.deductFoodOnAbsent : false,
        leaveAffectsBonus: prev ? prev.leaveAffectsBonus : false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      StorageService.saveMonthlySettings(settings);
    }
    setMonthlySettings(settings);
    setAttendanceRecords(StorageService.getAttendanceForMonth(year, month));
    setOtRecords(StorageService.getDailyOtForMonth(year, month));
  }, []);

  useEffect(() => {
    reloadMonthData(selectedYear, selectedMonth);
  }, [selectedYear, selectedMonth, reloadMonthData]);

  // 7. Salary Calculation for Active Month
  const calculationResult = useMemo(() => {
    return calculateMonthlySalary(monthlySettings, attendanceRecords, otRecords);
  }, [monthlySettings, attendanceRecords, otRecords]);

  // 8. Theme Sync
  useEffect(() => {
    const root = document.documentElement;
    const isDark =
      userSettings.theme === 'dark' ||
      (userSettings.theme === 'system' &&
        window.matchMedia('(prefers-color-scheme: dark)').matches);

    if (isDark) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [userSettings.theme]);

  // 9. Reminder Notification scheduler
  useEffect(() => {
    if (userSettings.reminderEnabled && userSettings.reminderTime) {
      const t = translations[userSettings.language];
      const cancel = NotificationService.scheduleDailyReminder(
        userSettings.reminderTime,
        t.reminderTitle,
        t.reminderBody
      );
      return cancel;
    }
  }, [userSettings.reminderEnabled, userSettings.reminderTime, userSettings.language]);

  // Handlers
  const handleUpdateUserSettings = (updated: Partial<UserSettings>) => {
    const next = { ...userSettings, ...updated };
    setUserSettings(next);
    StorageService.saveUserSettings(next);
  };

  const handleFirstTimeSetupSave = (settings: MonthlySalarySettings) => {
    StorageService.saveMonthlySettings(settings);
    setMonthlySettings(settings);
    handleUpdateUserSettings({ isFirstTimeSetupCompleted: true });
    setShowFirstTimeSetup(false);
  };

  const handleOpenDailyModal = (date: number) => {
    const existingAtt = attendanceRecords.find((r) => r.date === date);
    const existingOt = otRecords.find((r) => r.date === date);

    setDailyModalState({
      isOpen: true,
      date,
      status: existingAtt ? existingAtt.status : 'NOT_MARKED',
      otHours: existingOt ? existingOt.otHours : 0,
    });
  };

  const handleSaveDailyModal = (date: number, status: AttendanceStatus, otHours: number) => {
    // 1. Save Attendance
    const attRecord: AttendanceRecord = {
      id: `att_${selectedYear}_${selectedMonth}_${date}`,
      year: selectedYear,
      month: selectedMonth,
      date,
      status,
      updatedAt: new Date().toISOString(),
    };
    StorageService.saveAttendanceRecord(attRecord);

    // 2. Save OT
    const otRecord: DailyOTRecord = {
      id: `ot_${selectedYear}_${selectedMonth}_${date}`,
      year: selectedYear,
      month: selectedMonth,
      date,
      otHours,
      updatedAt: new Date().toISOString(),
    };
    StorageService.saveDailyOtRecord(otRecord);

    // 3. Update local state
    setAttendanceRecords(StorageService.getAttendanceForMonth(selectedYear, selectedMonth));
    setOtRecords(StorageService.getDailyOtForMonth(selectedYear, selectedMonth));
    setDailyModalState((prev) => ({ ...prev, status, otHours }));
  };

  const handleSaveMonthlySettings = (newSettings: MonthlySalarySettings) => {
    StorageService.saveMonthlySettings(newSettings);
    setMonthlySettings(newSettings);
  };

  const handleCopyPreviousMonth = (): boolean => {
    const copied = StorageService.copyPreviousMonthSettings(selectedYear, selectedMonth);
    if (copied) {
      setMonthlySettings(copied);
      return true;
    }
    return false;
  };

  const handleDownloadAndroidZip = async () => {
    try {
      setIsDownloadingZip(true);
      await downloadAndroidProjectZip();
    } catch (err) {
      console.error('Failed to download project zip:', err);
      alert('Error generating Android project ZIP. Please try again.');
    } finally {
      setIsDownloadingZip(false);
    }
  };

  const handleResetAllData = () => {
    StorageService.clearAllData();
    const defaults = StorageService.getUserSettings();
    setUserSettings(defaults);
    setShowFirstTimeSetup(true);
    setSelectedYear(2026);
    setSelectedMonth(9);
    reloadMonthData(2026, 9);
    setActiveTab('home');
  };

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors duration-200">
      {/* Top Navigation Bar */}
      <Navbar
        currentYear={selectedYear}
        currentMonth={selectedMonth}
        onMonthChange={(y, m) => {
          setSelectedYear(y);
          setSelectedMonth(m);
        }}
        language={userSettings.language}
        onLanguageChange={(lang) => handleUpdateUserSettings({ language: lang })}
        theme={userSettings.theme}
        onThemeChange={(th) => handleUpdateUserSettings({ theme: th })}
        onOpenMonthPicker={() => setIsMonthPickerModalOpen(true)}
        onDownloadAndroidZip={handleDownloadAndroidZip}
        isDownloadingZip={isDownloadingZip}
      />

      {/* Main Screen Content */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 pt-5 pb-24">
        {activeTab === 'home' && (
          <HomeScreen
            year={selectedYear}
            month={selectedMonth}
            calculation={calculationResult}
            settings={monthlySettings}
            onOpenDailyModalForDate={handleOpenDailyModal}
            onOpenMonthlySettings={() => setIsMonthlySettingsModalOpen(true)}
            onCopyPreviousMonth={handleCopyPreviousMonth}
            onNavigateToCalendar={() => setActiveTab('calendar')}
            language={userSettings.language}
          />
        )}

        {activeTab === 'calendar' && (
          <CalendarScreen
            year={selectedYear}
            month={selectedMonth}
            attendanceRecords={attendanceRecords}
            otRecords={otRecords}
            onDateClick={handleOpenDailyModal}
            language={userSettings.language}
          />
        )}

        {activeTab === 'summary' && (
          <SummaryScreen
            year={selectedYear}
            month={selectedMonth}
            calculation={calculationResult}
            settings={monthlySettings}
            language={userSettings.language}
          />
        )}

        {activeTab === 'history' && (
          <HistoryScreen
            onSelectMonth={(y, m) => {
              setSelectedYear(y);
              setSelectedMonth(m);
              setActiveTab('summary');
            }}
            language={userSettings.language}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsScreen
            userSettings={userSettings}
            onUpdateUserSettings={handleUpdateUserSettings}
            onDownloadAndroidZip={handleDownloadAndroidZip}
            isDownloadingZip={isDownloadingZip}
            onResetAllData={handleResetAllData}
            language={userSettings.language}
          />
        )}
      </main>

      {/* Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        language={userSettings.language}
      />

      {/* Modals */}
      <DailyAttendanceModal
        isOpen={dailyModalState.isOpen}
        onClose={() => setDailyModalState((prev) => ({ ...prev, isOpen: false }))}
        year={selectedYear}
        month={selectedMonth}
        date={dailyModalState.date}
        currentStatus={dailyModalState.status}
        currentOtHours={dailyModalState.otHours}
        onSave={handleSaveDailyModal}
        language={userSettings.language}
      />

      <MonthlySettingsModal
        isOpen={isMonthlySettingsModalOpen}
        onClose={() => setIsMonthlySettingsModalOpen(false)}
        year={selectedYear}
        month={selectedMonth}
        currentSettings={monthlySettings}
        onSave={handleSaveMonthlySettings}
        onCopyPreviousMonth={handleCopyPreviousMonth}
        language={userSettings.language}
      />

      <MonthPickerModal
        isOpen={isMonthPickerModalOpen}
        onClose={() => setIsMonthPickerModalOpen(false)}
        currentYear={selectedYear}
        currentMonth={selectedMonth}
        onSelect={(y, m) => {
          setSelectedYear(y);
          setSelectedMonth(m);
        }}
        language={userSettings.language}
      />

      <FirstTimeSetupModal
        isOpen={showFirstTimeSetup}
        onSave={handleFirstTimeSetupSave}
        initialYear={selectedYear}
        initialMonth={selectedMonth}
        language={userSettings.language}
      />
    </div>
  );
}
