/**
 * Localization strings for Bengali (বাংলা) and English
 */

export const translations = {
  bn: {
    appName: 'Salary & Attendance Manager',
    appSubtitle: 'বেতন ও হাজিরা ব্যবস্থাপক',
    
    // Navigation
    navHome: 'হোম',
    navCalendar: 'ক্যালেন্ডার',
    navSummary: 'সারসংক্ষেপ',
    navHistory: 'ইতিহাস',
    navSettings: 'সেটিংস',
    
    // Status
    statusPresent: 'উপস্থিত',
    statusAbsent: 'অনুপস্থিত',
    statusLeave: 'ছুটি',
    statusNotMarked: 'চিহ্নিত নয়',
    clearStatus: 'মুছুন',
    
    // Dashboard & Salary
    expectedSalary: 'প্রত্যাশিত বেতন',
    breakdown: 'বেতনের বিবরণ',
    basicSalary: 'মূল বেতন',
    transportAllowance: 'যাতায়াত ভাতা',
    foodAllowance: 'খাদ্য ভাতা',
    attendanceBonus: 'উপস্থিতি বোনাস',
    otPay: 'ওভারটাইম আয়',
    absentDeduction: 'অনুপস্থিতির কর্তন',
    totalDeductions: 'মোট কর্তন',
    earnedSalary: 'অর্জিত বেতন',
    dailyBasicSalary: 'দৈনিক মূল বেতন',
    
    // Stats counters
    statsPresent: 'উপস্থিত',
    statsAbsent: 'অনুপস্থিত',
    statsLeave: 'ছুটি',
    statsNotMarked: 'চিহ্নিত নয়',
    statsOtHours: 'ওভারটাইম ঘণ্টা',
    hoursShort: 'ঘণ্টা',
    
    // Alerts & Warnings
    unmarkedWarning: 'আপনার {count} দিনের হাজিরা এখনো চিহ্নিত করা হয়নি।',
    bonusLostAbsent: 'অনুপস্থিতির কারণে উপস্থিতি বোনাস পাওয়া যাবে না (৳০)।',
    bonusLostLeave: 'ছুটি গ্রহণের কারণে উপস্থিতি বোনাস বাতিল হয়েছে (৳০)।',
    fullBonusEarned: 'কোনো অনুপস্থিতি না থাকায় পূর্ণ বোনাস অর্জিত হয়েছে!',
    
    // Quick Actions
    markToday: 'আজকের হাজিরা দিন',
    todayDate: 'আজকের তারিখ',
    copyPrevSettings: 'পূর্ববর্তী মাসের সেটিংস কপি করুন',
    copiedSuccess: 'পূর্ববর্তী মাসের বেতন সেটিংস সফলভাবে কপি করা হয়েছে!',
    noPrevSettings: 'পূর্ববর্তী মাসের কোনো সেটিংস পাওয়া যায়নি।',
    
    // Month picker
    selectMonthYear: 'মাস ও বছর নির্বাচন করুন',
    prevMonth: 'পূর্ববর্তী মাস',
    nextMonth: 'পরবর্তী মাস',
    currentMonth: 'চলতি মাস',
    
    // Calendar screen
    calendarTitle: 'মাসিক হাজিরা ক্যালেন্ডার',
    tapToMark: 'তারিখ নির্বাচন করে হাজিরা ও ওভারটাইম যোগ করুন',
    dayNames: ['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র', 'শনি'],
    fullDayNames: ['রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার'],
    monthNames: [
      'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
      'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
    ],
    
    // Daily Attendance Modal
    dailyEntryTitle: 'দৈনিক হাজিরা ও ওভারটাইম',
    dateLabel: 'তারিখ',
    dayLabel: 'বার',
    currentStatus: 'বর্তমান অবস্থা',
    selectAttendance: 'হাজিরা চিহ্নিত করুন',
    otHoursLabel: 'ওভারটাইম (ঘণ্টা)',
    otHoursPlaceholder: 'যেমন: ১.৫, ২',
    otQuickPreset: 'দ্রুত নির্বাচন',
    saveClose: 'সংরক্ষণ করুন',
    autoSaved: 'স্বয়ংক্রিয়ভাবে সংরক্ষিত হয়েছে',
    
    // Summary screen
    summaryTitle: 'মাসিক বেতনের পূর্ণাঙ্গ সারসংক্ষেপ',
    attendanceOverview: 'হাজিরা বিবরণ',
    workingDays: 'মোট কর্মদিবস',
    salaryBreakdown: 'বেতন ও ভাতা হিসাব',
    otSummary: 'ওভারটাইম বিবরণ',
    totalOtHours: 'মোট ওভারটাইম',
    otRate: 'প্রতি ঘণ্টা রেট',
    totalOtPay: 'মোট ওভারটাইম আয়',
    netPayable: 'সর্বমোট প্রাপ্য বেতন',
    printOrExport: 'সারসংক্ষেপ প্রিন্ট / শেয়ার করুন',
    
    // History screen
    historyTitle: 'বেতন ইতিহাস',
    historySubtitle: 'প্রতিটি মাসের সংরক্ষিত বিবরণ ও হিসাব',
    noHistoryYet: 'এখনো কোনো মাসের ইতিহাস সংরক্ষিত নেই।',
    viewDetails: 'বিস্তারিত দেখুন',
    
    // Settings screen
    settingsTitle: 'অ্যাপ সেটিংস',
    preferences: 'পছন্দসমূহ',
    language: 'ভাষা (Language)',
    theme: 'থিম (Theme)',
    themeSystem: 'সিস্টেম ডিফল্ট',
    themeLight: 'লাইট মোড',
    themeDark: 'ডার্ক মোড',
    currency: 'মুদ্রা',
    
    // Reminders
    remindersSection: 'হাজিরা রিমাইন্ডার',
    enableReminder: 'প্রতিদিনের হাজিরা রিমাইন্ডার',
    reminderTime: 'রিমাইন্ডার সময়',
    testNotification: 'এখনই নোটিফিকেশন পরীক্ষা করুন',
    notificationSuccess: 'নোটিফিকেশন পাঠানো হয়েছে!',
    notificationPermissionDenied: 'ব্রাউজার নোটিফিকেশন পারমিশন দেওয়া হয়নি। অনুগ্রহ করে পারমিশন দিন।',
    reminderBengaliText: 'আজকের Attendance Mark করুন',
    reminderEnglishText: "Please mark today's attendance.",
    monthlyReminderText: 'এই মাসের Salary Summary প্রস্তুত।',
    
    // Monthly Configuration
    monthlyConfigTitle: 'চলতি মাসের বেতন সেটিংস',
    configureMonth: 'মাসিক সেটিংস পরিবর্তন করুন',
    saveSettings: 'সেটিংস সংরক্ষণ করুন',
    transportDeductionLabel: 'অনুপস্থিত থাকলে যাতায়াত ভাতা কর্তন?',
    foodDeductionLabel: 'অনুপস্থিত থাকলে খাদ্য ভাতা কর্তন?',
    leaveAffectsBonusLabel: 'ছুটি নিলে উপস্থিতি বোনাস বাতিল হবে?',
    yes: 'হ্যাঁ',
    no: 'না',
    
    // First-time setup
    welcomeTitle: 'Salary & Attendance Manager-এ স্বাগতম',
    welcomeSubtitle: 'শুরু করার জন্য আপনার মাসিক মূল বেতন ও ভাতার তথ্য পূরণ করুন। এই তথ্য দিয়ে প্রতি মাসের বেতন স্বয়ংক্রিয়ভাবে হিসাব করা হবে।',
    saveAndContinue: 'সংরক্ষণ করুন এবং এগিয়ে যান',
    
    // About & Data
    aboutApp: 'অ্যাপ সম্পর্কিত',
    aboutDescription: 'Salary & Attendance Manager একটি সম্পূর্ণ অফলাইন, নিরাপদ বেতন ও হাজিরা ট্র্যাকার। কোনো তথ্য ইন্টারনেটে পাঠানো হয় না।',
    appVersion: 'ভার্সন ১.০.০ (Android Ready)',
    privacyNotice: 'আপনার গোপনীয়তা সম্পূর্ণ সুরক্ষিত। সকল ডেটা ডিভাইসের লোকাল মেমরিতে সংরক্ষিত থাকে।',
    resetAllData: 'সব ডেটা মুছে ফেলুন (Reset)',
    resetConfirmTitle: 'আপনি কি নিশ্চিত?',
    resetConfirmDesc: 'আপনার সকল সংরক্ষিত হাজিরা, ওভারটাইম এবং বেতন সেটিংস স্থায়ীভাবে মুছে যাবে। এটি পূর্বাবস্থায় ফেরানো যাবে না।',
    cancel: 'বাতিল',
    confirmReset: 'হ্যাঁ, সবকিছু মুছুন',
    dataResetSuccess: 'সকল ডেটা সফলভাবে রিসেট করা হয়েছে।',
    
    // Android Project Export
    downloadAndroidZip: 'Android Studio প্রজেক্ট ডাউনলোড (.zip)',
    downloadAndroidDesc: 'সম্পূর্ণ Kotlin + Jetpack Compose + Room DB সোর্স কোড জিপ ফাইলে ডাউনলোড করুন এবং Android Studio দিয়ে সরাসরি APK বিল্ড করুন।',
    generatingZip: 'Android প্রজেক্ট জিপ তৈরি হচ্ছে...',
    downloadReady: 'Android প্রজেক্ট ডাউনলোড প্রস্তুত!',
    
    // Validation
    valWorkingDaysReq: 'কর্মদিবস ০ থেকে বড় হতে হবে',
    valWorkingDaysMax: 'কর্মদিবস মাসের মোট দিনের চেয়ে বেশি হতে পারে না',
    valPositiveNumbers: 'মান ঋণাত্মক হতে পারে না',
  },
  
  en: {
    appName: 'Salary & Attendance Manager',
    appSubtitle: 'Salary & Attendance Tracker',
    
    // Navigation
    navHome: 'Home',
    navCalendar: 'Calendar',
    navSummary: 'Summary',
    navHistory: 'History',
    navSettings: 'Settings',
    
    // Status
    statusPresent: 'Present',
    statusAbsent: 'Absent',
    statusLeave: 'Leave',
    statusNotMarked: 'Not Marked',
    clearStatus: 'Clear',
    
    // Dashboard & Salary
    expectedSalary: 'EXPECTED SALARY',
    breakdown: 'Salary Breakdown',
    basicSalary: 'Basic Salary',
    transportAllowance: 'Transport Allowance',
    foodAllowance: 'Food Allowance',
    attendanceBonus: 'Attendance Bonus',
    otPay: 'OT Pay',
    absentDeduction: 'Absent Deduction',
    totalDeductions: 'Total Deductions',
    earnedSalary: 'Earned Salary',
    dailyBasicSalary: 'Daily Basic Salary',
    
    // Stats counters
    statsPresent: 'Present',
    statsAbsent: 'Absent',
    statsLeave: 'Leave',
    statsNotMarked: 'Not Marked',
    statsOtHours: 'OT Hours',
    hoursShort: 'hrs',
    
    // Alerts & Warnings
    unmarkedWarning: 'You have {count} unmarked attendance days.',
    bonusLostAbsent: 'Attendance bonus forfeited due to absent days (৳0).',
    bonusLostLeave: 'Attendance bonus forfeited due to leave days (৳0).',
    fullBonusEarned: 'Full attendance bonus earned! (0 absences)',
    
    // Quick Actions
    markToday: "Mark Today's Attendance",
    todayDate: "Today's Date",
    copyPrevSettings: 'Copy Previous Month Settings',
    copiedSuccess: 'Previous month salary configuration copied successfully!',
    noPrevSettings: 'No previous month settings found.',
    
    // Month picker
    selectMonthYear: 'Select Month & Year',
    prevMonth: 'Previous Month',
    nextMonth: 'Next Month',
    currentMonth: 'Current Month',
    
    // Calendar screen
    calendarTitle: 'Monthly Attendance Calendar',
    tapToMark: 'Tap any date to log attendance & overtime',
    dayNames: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    fullDayNames: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
    monthNames: [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ],
    
    // Daily Attendance Modal
    dailyEntryTitle: 'Daily Attendance & Overtime',
    dateLabel: 'Date',
    dayLabel: 'Day',
    currentStatus: 'Current Status',
    selectAttendance: 'Select Attendance Status',
    otHoursLabel: 'Overtime (Hours)',
    otHoursPlaceholder: 'e.g. 1.5, 2.0',
    otQuickPreset: 'Quick Preset',
    saveClose: 'Save & Close',
    autoSaved: 'Saved automatically',
    
    // Summary screen
    summaryTitle: 'Monthly Salary Summary',
    attendanceOverview: 'Attendance Overview',
    workingDays: 'Total Working Days',
    salaryBreakdown: 'Salary & Allowances Breakdown',
    otSummary: 'Overtime (OT) Summary',
    totalOtHours: 'Total OT Hours',
    otRate: 'OT Rate Per Hour',
    totalOtPay: 'Total OT Pay',
    netPayable: 'Final Expected Salary',
    printOrExport: 'Print / Share Summary',
    
    // History screen
    historyTitle: 'Salary History',
    historySubtitle: 'Historical months and calculated records',
    noHistoryYet: 'No monthly history recorded yet.',
    viewDetails: 'View Details',
    
    // Settings screen
    settingsTitle: 'Settings',
    preferences: 'Preferences',
    language: 'Language',
    theme: 'Theme',
    themeSystem: 'System Default',
    themeLight: 'Light Mode',
    themeDark: 'Dark Mode',
    currency: 'Currency',
    
    // Reminders
    remindersSection: 'Attendance Reminders',
    enableReminder: 'Daily Attendance Reminder',
    reminderTime: 'Reminder Time',
    testNotification: 'Test Reminder Now',
    notificationSuccess: 'Notification sent!',
    notificationPermissionDenied: 'Notification permission not granted in browser.',
    reminderBengaliText: 'আজকের Attendance Mark করুন',
    reminderEnglishText: "Please mark today's attendance.",
    monthlyReminderText: "This month's Salary Summary is ready.",
    
    // Monthly Configuration
    monthlyConfigTitle: 'Current Month Salary Configuration',
    configureMonth: 'Edit Monthly Settings',
    saveSettings: 'Save Settings',
    transportDeductionLabel: 'Deduct Transport Allowance on Absent?',
    foodDeductionLabel: 'Deduct Food Allowance on Absent?',
    leaveAffectsBonusLabel: 'Does Leave Affect Attendance Bonus?',
    yes: 'Yes',
    no: 'No',
    
    // First-time setup
    welcomeTitle: 'Welcome to Salary & Attendance Manager',
    welcomeSubtitle: 'Please set up your initial monthly basic salary, allowances, and rules. These will be used to calculate your expected salary automatically.',
    saveAndContinue: 'Save & Continue',
    
    // About & Data
    aboutApp: 'About App',
    aboutDescription: 'Salary & Attendance Manager is a fully offline, private salary and attendance tracker. No data leaves your device.',
    appVersion: 'Version 1.0.0 (Android Ready)',
    privacyNotice: 'Your privacy is guaranteed. All records and settings are stored locally on device storage.',
    resetAllData: 'Reset All Data',
    resetConfirmTitle: 'Are you sure?',
    resetConfirmDesc: 'This will permanently delete all attendance marks, overtime records, and salary configurations. This cannot be undone.',
    cancel: 'Cancel',
    confirmReset: 'Yes, Reset Everything',
    dataResetSuccess: 'All data has been reset successfully.',
    
    // Android Project Export
    downloadAndroidZip: 'Download Android Studio Project (.zip)',
    downloadAndroidDesc: 'Download the complete production-grade Kotlin + Jetpack Compose + Room DB source project to build an APK in Android Studio.',
    generatingZip: 'Packaging Android Project...',
    downloadReady: 'Android Project Ready for Download!',
    
    // Validation
    valWorkingDaysReq: 'Working days must be greater than 0',
    valWorkingDaysMax: 'Working days cannot exceed days in month',
    valPositiveNumbers: 'Values cannot be negative',
  }
};
