import React, { useState, useEffect } from 'react';
import { X, Copy, Check, Save, Banknote, Calendar, Car, Utensils, Award, Clock, AlertCircle } from 'lucide-react';
import { MonthlySalarySettings, AppLanguage } from '../types';
import { translations } from '../locales/translations';
import { toBengaliNumerals } from '../services/calculationEngine';

interface MonthlySettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  year: number;
  month: number;
  currentSettings: MonthlySalarySettings;
  onSave: (settings: MonthlySalarySettings) => void;
  onCopyPreviousMonth: () => boolean;
  language: AppLanguage;
}

export const MonthlySettingsModal: React.FC<MonthlySettingsModalProps> = ({
  isOpen,
  onClose,
  year,
  month,
  currentSettings,
  onSave,
  onCopyPreviousMonth,
  language,
}) => {
  const t = translations[language];

  const [basicSalary, setBasicSalary] = useState<string>(String(currentSettings.basicSalary));
  const [transportAllowance, setTransportAllowance] = useState<string>(String(currentSettings.transportAllowance));
  const [foodAllowance, setFoodAllowance] = useState<string>(String(currentSettings.foodAllowance));
  const [attendanceBonus, setAttendanceBonus] = useState<string>(String(currentSettings.attendanceBonus));
  const [workingDays, setWorkingDays] = useState<string>(String(currentSettings.workingDays));
  const [otRate, setOtRate] = useState<string>(String(currentSettings.otRate));

  const [deductTransportOnAbsent, setDeductTransportOnAbsent] = useState<boolean>(
    currentSettings.deductTransportOnAbsent
  );
  const [deductFoodOnAbsent, setDeductFoodOnAbsent] = useState<boolean>(
    currentSettings.deductFoodOnAbsent
  );
  const [leaveAffectsBonus, setLeaveAffectsBonus] = useState<boolean>(
    currentSettings.leaveAffectsBonus
  );

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [validationError, setValidationError] = useState<string | null>(null);

  useEffect(() => {
    setBasicSalary(String(currentSettings.basicSalary));
    setTransportAllowance(String(currentSettings.transportAllowance));
    setFoodAllowance(String(currentSettings.foodAllowance));
    setAttendanceBonus(String(currentSettings.attendanceBonus));
    setWorkingDays(String(currentSettings.workingDays));
    setOtRate(String(currentSettings.otRate));
    setDeductTransportOnAbsent(currentSettings.deductTransportOnAbsent);
    setDeductFoodOnAbsent(currentSettings.deductFoodOnAbsent);
    setLeaveAffectsBonus(currentSettings.leaveAffectsBonus);
    setValidationError(null);
    setToastMessage(null);
  }, [currentSettings, year, month, isOpen]);

  if (!isOpen) return null;

  const monthName = t.monthNames[month - 1];
  const displayYear = language === 'bn' ? toBengaliNumerals(year) : year;

  const handleCopyPrev = () => {
    const success = onCopyPreviousMonth();
    if (success) {
      setToastMessage(t.copiedSuccess);
      setTimeout(() => setToastMessage(null), 3000);
    } else {
      setToastMessage(t.noPrevSettings);
      setTimeout(() => setToastMessage(null), 3000);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const parsedBasic = parseFloat(basicSalary);
    const parsedTransport = parseFloat(transportAllowance) || 0;
    const parsedFood = parseFloat(foodAllowance) || 0;
    const parsedBonus = parseFloat(attendanceBonus) || 0;
    const parsedDays = parseInt(workingDays, 10);
    const parsedOtRate = parseFloat(otRate) || 0;

    if (isNaN(parsedBasic) || parsedBasic < 0) {
      setValidationError(t.valPositiveNumbers);
      return;
    }
    if (isNaN(parsedDays) || parsedDays <= 0) {
      setValidationError(t.valWorkingDaysReq);
      return;
    }
    if (parsedDays > 31) {
      setValidationError(t.valWorkingDaysMax);
      return;
    }
    if (parsedTransport < 0 || parsedFood < 0 || parsedBonus < 0 || parsedOtRate < 0) {
      setValidationError(t.valPositiveNumbers);
      return;
    }

    const updated: MonthlySalarySettings = {
      ...currentSettings,
      basicSalary: parsedBasic,
      transportAllowance: parsedTransport,
      foodAllowance: parsedFood,
      attendanceBonus: parsedBonus,
      workingDays: parsedDays,
      otRate: parsedOtRate,
      deductTransportOnAbsent,
      deductFoodOnAbsent,
      leaveAffectsBonus,
      updatedAt: new Date().toISOString(),
    };

    onSave(updated);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/65 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/80 dark:bg-slate-900/80">
          <div>
            <h3 className="font-bold text-slate-900 dark:text-white text-base">
              {t.monthlyConfigTitle}
            </h3>
            <p className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
              {monthName} {displayYear}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Copy Previous Month Bar */}
        <div className="px-5 py-3 bg-emerald-50/60 dark:bg-emerald-950/30 border-b border-emerald-100 dark:border-emerald-900/40 flex items-center justify-between">
          <span className="text-xs text-emerald-800 dark:text-emerald-300 font-medium">
            {language === 'bn' ? 'আগের মাসের সেটিং ব্যবহার করতে চান?' : 'Want to inherit previous month setup?'}
          </span>
          <button
            id="btn-copy-prev-settings"
            type="button"
            onClick={handleCopyPrev}
            className="px-3 py-1.5 text-xs font-bold rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white flex items-center gap-1.5 shadow-xs transition"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>{t.copyPrevSettings}</span>
          </button>
        </div>

        {toastMessage && (
          <div className="mx-5 mt-3 p-2.5 bg-emerald-100 dark:bg-emerald-900/40 text-emerald-800 dark:text-emerald-300 rounded-xl text-xs font-semibold flex items-center gap-2">
            <Check className="w-4 h-4 shrink-0" />
            <span>{toastMessage}</span>
          </div>
        )}

        {validationError && (
          <div className="mx-5 mt-3 p-2.5 bg-rose-100 dark:bg-rose-950/40 text-rose-800 dark:text-rose-300 rounded-xl text-xs font-semibold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{validationError}</span>
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleFormSubmit} className="p-5 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Basic Salary */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Banknote className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span>{t.basicSalary} (৳)</span>
              </label>
              <input
                type="number"
                min="0"
                step="any"
                required
                value={basicSalary}
                onChange={(e) => setBasicSalary(e.target.value)}
                className="w-full px-3 py-2 text-sm font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500/40 focus:outline-none"
              />
            </div>

            {/* Total Working Days */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span>{t.workingDays}</span>
              </label>
              <input
                type="number"
                min="1"
                max="31"
                required
                value={workingDays}
                onChange={(e) => setWorkingDays(e.target.value)}
                className="w-full px-3 py-2 text-sm font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500/40 focus:outline-none"
              />
            </div>

            {/* Transport Allowance */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Car className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                <span>{t.transportAllowance} (৳)</span>
              </label>
              <input
                type="number"
                min="0"
                step="any"
                value={transportAllowance}
                onChange={(e) => setTransportAllowance(e.target.value)}
                className="w-full px-3 py-2 text-sm font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500/40 focus:outline-none"
              />
            </div>

            {/* Food Allowance */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Utensils className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                <span>{t.foodAllowance} (৳)</span>
              </label>
              <input
                type="number"
                min="0"
                step="any"
                value={foodAllowance}
                onChange={(e) => setFoodAllowance(e.target.value)}
                className="w-full px-3 py-2 text-sm font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500/40 focus:outline-none"
              />
            </div>

            {/* Attendance Bonus */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Award className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
                <span>{t.attendanceBonus} (৳)</span>
              </label>
              <input
                type="number"
                min="0"
                step="any"
                value={attendanceBonus}
                onChange={(e) => setAttendanceBonus(e.target.value)}
                className="w-full px-3 py-2 text-sm font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500/40 focus:outline-none"
              />
            </div>

            {/* OT Rate Per Hour */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                <span>{t.otRate} (৳/hr)</span>
              </label>
              <input
                type="number"
                min="0"
                step="any"
                value={otRate}
                onChange={(e) => setOtRate(e.target.value)}
                className="w-full px-3 py-2 text-sm font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500/40 focus:outline-none"
              />
            </div>
          </div>

          {/* Section: Rule Toggles */}
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2.5">
            {/* Deduct Transport on Absent */}
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/60">
              <span className="text-xs font-medium text-slate-700 dark:text-slate-200 pr-2">
                {t.transportDeductionLabel}
              </span>
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => setDeductTransportOnAbsent(false)}
                  className={`px-2.5 py-1 text-xs font-bold rounded-lg transition ${
                    !deductTransportOnAbsent
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {t.no}
                </button>
                <button
                  type="button"
                  onClick={() => setDeductTransportOnAbsent(true)}
                  className={`px-2.5 py-1 text-xs font-bold rounded-lg transition ${
                    deductTransportOnAbsent
                      ? 'bg-rose-600 text-white'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {t.yes}
                </button>
              </div>
            </div>

            {/* Deduct Food on Absent */}
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/60">
              <span className="text-xs font-medium text-slate-700 dark:text-slate-200 pr-2">
                {t.foodDeductionLabel}
              </span>
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => setDeductFoodOnAbsent(false)}
                  className={`px-2.5 py-1 text-xs font-bold rounded-lg transition ${
                    !deductFoodOnAbsent
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {t.no}
                </button>
                <button
                  type="button"
                  onClick={() => setDeductFoodOnAbsent(true)}
                  className={`px-2.5 py-1 text-xs font-bold rounded-lg transition ${
                    deductFoodOnAbsent
                      ? 'bg-rose-600 text-white'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {t.yes}
                </button>
              </div>
            </div>

            {/* Leave Affects Attendance Bonus */}
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/60">
              <span className="text-xs font-medium text-slate-700 dark:text-slate-200 pr-2">
                {t.leaveAffectsBonusLabel}
              </span>
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => setLeaveAffectsBonus(false)}
                  className={`px-2.5 py-1 text-xs font-bold rounded-lg transition ${
                    !leaveAffectsBonus
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {t.no}
                </button>
                <button
                  type="button"
                  onClick={() => setLeaveAffectsBonus(true)}
                  className={`px-2.5 py-1 text-xs font-bold rounded-lg transition ${
                    leaveAffectsBonus
                      ? 'bg-amber-600 text-white'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {t.yes}
                </button>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            >
              {t.cancel}
            </button>
            <button
              id="btn-save-monthly-settings-modal"
              type="submit"
              className="px-5 py-2 text-xs font-bold rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition flex items-center gap-1.5"
            >
              <Save className="w-4 h-4" />
              <span>{t.saveSettings}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
