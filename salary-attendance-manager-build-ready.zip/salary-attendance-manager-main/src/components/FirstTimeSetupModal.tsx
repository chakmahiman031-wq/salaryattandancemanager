import React, { useState } from 'react';
import { ShieldCheck, Banknote, Calendar, Car, Utensils, Award, Clock, ArrowRight, AlertCircle } from 'lucide-react';
import { MonthlySalarySettings, AppLanguage } from '../types';
import { translations } from '../locales/translations';

interface FirstTimeSetupModalProps {
  isOpen: boolean;
  onSave: (settings: MonthlySalarySettings) => void;
  initialYear: number;
  initialMonth: number;
  language: AppLanguage;
}

export const FirstTimeSetupModal: React.FC<FirstTimeSetupModalProps> = ({
  isOpen,
  onSave,
  initialYear,
  initialMonth,
  language,
}) => {
  const t = translations[language];

  // Default values matching user spec examples
  const [basicSalary, setBasicSalary] = useState<string>('20000');
  const [transportAllowance, setTransportAllowance] = useState<string>('3000');
  const [foodAllowance, setFoodAllowance] = useState<string>('2000');
  const [attendanceBonus, setAttendanceBonus] = useState<string>('2000');
  const [workingDays, setWorkingDays] = useState<string>('26');
  const [otRate, setOtRate] = useState<string>('100');

  const [deductTransportOnAbsent, setDeductTransportOnAbsent] = useState<boolean>(false);
  const [deductFoodOnAbsent, setDeductFoodOnAbsent] = useState<boolean>(false);
  const [leaveAffectsBonus, setLeaveAffectsBonus] = useState<boolean>(false);

  const [validationError, setValidationError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const parsedBasic = parseFloat(basicSalary);
    const parsedTransport = parseFloat(transportAllowance) || 0;
    const parsedFood = parseFloat(foodAllowance) || 0;
    const parsedBonus = parseFloat(attendanceBonus) || 0;
    const parsedDays = parseInt(workingDays, 10);
    const parsedOtRate = parseFloat(otRate) || 0;

    if (isNaN(parsedBasic) || parsedBasic < 0) {
      setValidationError(t.valPositiveNumbers);
      return;
    }
    if (isNaN(parsedDays) || parsedDays <= 0) {
      setValidationError(t.valWorkingDaysReq);
      return;
    }
    if (parsedDays > 31) {
      setValidationError(t.valWorkingDaysMax);
      return;
    }
    if (parsedTransport < 0 || parsedFood < 0 || parsedBonus < 0 || parsedOtRate < 0) {
      setValidationError(t.valPositiveNumbers);
      return;
    }

    const settings: MonthlySalarySettings = {
      id: `settings_${initialYear}_${initialMonth}`,
      year: initialYear,
      month: initialMonth,
      basicSalary: parsedBasic,
      transportAllowance: parsedTransport,
      foodAllowance: parsedFood,
      attendanceBonus: parsedBonus,
      workingDays: parsedDays,
      otRate: parsedOtRate,
      deductTransportOnAbsent,
      deductFoodOnAbsent,
      leaveAffectsBonus,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    onSave(settings);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6">
        {/* Banner with Logo */}
        <div className="p-6 bg-gradient-to-br from-emerald-600 to-teal-700 text-white relative">
          <div className="flex items-center gap-3">
            <img 
              src="/logo.jpg" 
              alt="Logo" 
              className="w-12 h-12 rounded-xl object-cover ring-2 ring-white/30 shadow-md"
              onError={(e) => {
                (e.target as HTMLElement).style.display = 'none';
              }} 
            />
            <div>
              <h2 className="text-xl font-extrabold tracking-tight">
                {t.welcomeTitle}
              </h2>
              <p className="text-xs text-emerald-100 mt-0.5">
                {t.welcomeSubtitle}
              </p>
            </div>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {validationError && (
            <div className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 rounded-xl text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{validationError}</span>
            </div>
          )}

          {/* Section: Numerical Inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {/* Basic Salary */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Banknote className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span>{t.basicSalary} (৳)</span>
              </label>
              <input
                id="input-setup-basic-salary"
                type="number"
                min="0"
                step="any"
                required
                value={basicSalary}
                onChange={(e) => setBasicSalary(e.target.value)}
                placeholder="20000"
                className="w-full px-3.5 py-2 text-sm font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500/40 focus:outline-none"
              />
            </div>

            {/* Total Working Days */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span>{t.workingDays}</span>
              </label>
              <input
                id="input-setup-working-days"
                type="number"
                min="1"
                max="31"
                required
                value={workingDays}
                onChange={(e) => setWorkingDays(e.target.value)}
                placeholder="26"
                className="w-full px-3.5 py-2 text-sm font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500/40 focus:outline-none"
              />
            </div>

            {/* Transport Allowance */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Car className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                <span>{t.transportAllowance} (৳)</span>
              </label>
              <input
                id="input-setup-transport"
                type="number"
                min="0"
                step="any"
                value={transportAllowance}
                onChange={(e) => setTransportAllowance(e.target.value)}
                placeholder="3000"
                className="w-full px-3.5 py-2 text-sm font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500/40 focus:outline-none"
              />
            </div>

            {/* Food Allowance */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Utensils className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                <span>{t.foodAllowance} (৳)</span>
              </label>
              <input
                id="input-setup-food"
                type="number"
                min="0"
                step="any"
                value={foodAllowance}
                onChange={(e) => setFoodAllowance(e.target.value)}
                placeholder="2000"
                className="w-full px-3.5 py-2 text-sm font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500/40 focus:outline-none"
              />
            </div>

            {/* Attendance Bonus */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Award className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
                <span>{t.attendanceBonus} (৳)</span>
              </label>
              <input
                id="input-setup-bonus"
                type="number"
                min="0"
                step="any"
                value={attendanceBonus}
                onChange={(e) => setAttendanceBonus(e.target.value)}
                placeholder="2000"
                className="w-full px-3.5 py-2 text-sm font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500/40 focus:outline-none"
              />
            </div>

            {/* OT Rate Per Hour */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                <span>{t.otRate} (৳/hr)</span>
              </label>
              <input
                id="input-setup-ot-rate"
                type="number"
                min="0"
                step="any"
                value={otRate}
                onChange={(e) => setOtRate(e.target.value)}
                placeholder="100"
                className="w-full px-3.5 py-2 text-sm font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500/40 focus:outline-none"
              />
            </div>
          </div>

          {/* Section: Rule Toggles */}
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2.5">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              {language === 'bn' ? 'কর্তন ও বোনাস নিয়মাবলী' : 'Deduction & Bonus Rules'}
            </h4>

            {/* Deduct Transport on Absent */}
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/60">
              <span className="text-xs font-medium text-slate-700 dark:text-slate-200 pr-2">
                {t.transportDeductionLabel}
              </span>
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => setDeductTransportOnAbsent(false)}
                  className={`px-2.5 py-1 text-xs font-bold rounded-lg transition ${
                    !deductTransportOnAbsent
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {t.no}
                </button>
                <button
                  type="button"
                  onClick={() => setDeductTransportOnAbsent(true)}
                  className={`px-2.5 py-1 text-xs font-bold rounded-lg transition ${
                    deductTransportOnAbsent
                      ? 'bg-rose-600 text-white'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {t.yes}
                </button>
              </div>
            </div>

            {/* Deduct Food on Absent */}
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/60">
              <span className="text-xs font-medium text-slate-700 dark:text-slate-200 pr-2">
                {t.foodDeductionLabel}
              </span>
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => setDeductFoodOnAbsent(false)}
                  className={`px-2.5 py-1 text-xs font-bold rounded-lg transition ${
                    !deductFoodOnAbsent
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {t.no}
                </button>
                <button
                  type="button"
                  onClick={() => setDeductFoodOnAbsent(true)}
                  className={`px-2.5 py-1 text-xs font-bold rounded-lg transition ${
                    deductFoodOnAbsent
                      ? 'bg-rose-600 text-white'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {t.yes}
                </button>
              </div>
            </div>

            {/* Leave Affects Attendance Bonus */}
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/60">
              <span className="text-xs font-medium text-slate-700 dark:text-slate-200 pr-2">
                {t.leaveAffectsBonusLabel}
              </span>
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => setLeaveAffectsBonus(false)}
                  className={`px-2.5 py-1 text-xs font-bold rounded-lg transition ${
                    !leaveAffectsBonus
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {t.no}
                </button>
                <button
                  type="button"
                  onClick={() => setLeaveAffectsBonus(true)}
                  className={`px-2.5 py-1 text-xs font-bold rounded-lg transition ${
                    leaveAffectsBonus
                      ? 'bg-amber-600 text-white'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {t.yes}
                </button>
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <div className="pt-3">
            <button
              id="btn-save-first-time-setup"
              type="submit"
              className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-700 active:scale-99 text-white font-bold text-sm rounded-xl shadow-md shadow-emerald-600/20 transition flex items-center justify-center gap-2"
            >
              <span>{t.saveAndContinue}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
