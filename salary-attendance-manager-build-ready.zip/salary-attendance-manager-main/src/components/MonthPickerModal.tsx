import React, { useState } from 'react';
import { X, Calendar as CalendarIcon, Check } from 'lucide-react';
import { AppLanguage } from '../types';
import { translations } from '../locales/translations';
import { toBengaliNumerals } from '../services/calculationEngine';

interface MonthPickerModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentYear: number;
  currentMonth: number;
  onSelect: (year: number, month: number) => void;
  language: AppLanguage;
}

export const MonthPickerModal: React.FC<MonthPickerModalProps> = ({
  isOpen,
  onClose,
  currentYear,
  currentMonth,
  onSelect,
  language,
}) => {
  const t = translations[language];

  const [selectedYear, setSelectedYear] = useState<number>(currentYear);
  const [selectedMonth, setSelectedMonth] = useState<number>(currentMonth);

  if (!isOpen) return null;

  const now = new Date();
  const currentActualYear = now.getFullYear();
  const currentActualMonth = now.getMonth() + 1;

  // Years range: 2024 to 2030
  const years = [2024, 2025, 2026, 2027, 2028, 2029, 2030];

  const handleApply = () => {
    onSelect(selectedYear, selectedMonth);
    onClose();
  };

  const handleCurrentMonthJump = () => {
    onSelect(currentActualYear, currentActualMonth);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CalendarIcon className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <h3 className="font-bold text-slate-900 dark:text-white text-sm sm:text-base">
              {t.selectMonthYear}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          {/* Year Selector */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
              {language === 'bn' ? 'বছর নির্বাচন' : 'Select Year'}
            </label>
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1.5 scrollbar-none">
              {years.map((y) => (
                <button
                  key={y}
                  onClick={() => setSelectedYear(y)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold shrink-0 transition ${
                    selectedYear === y
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {language === 'bn' ? toBengaliNumerals(y) : y}
                </button>
              ))}
            </div>
          </div>

          {/* Months Grid */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
              {language === 'bn' ? 'মাস নির্বাচন' : 'Select Month'}
            </label>
            <div className="grid grid-cols-3 gap-2">
              {t.monthNames.map((mName, idx) => {
                const mNum = idx + 1;
                const isSelected = selectedMonth === mNum;
                const isCurrentActual = selectedYear === currentActualYear && mNum === currentActualMonth;

                return (
                  <button
                    key={mNum}
                    onClick={() => setSelectedMonth(mNum)}
                    className={`py-2 px-2 rounded-xl text-xs font-bold transition flex flex-col items-center justify-center relative ${
                      isSelected
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'bg-slate-50 hover:bg-slate-100 dark:bg-slate-800/60 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200/60 dark:border-slate-700/60'
                    }`}
                  >
                    <span>{mName}</span>
                    {isCurrentActual && !isSelected && (
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-0.5" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3.5 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <button
            type="button"
            onClick={handleCurrentMonthJump}
            className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline"
          >
            {t.currentMonth}
          </button>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 text-xs font-semibold text-slate-500 hover:text-slate-700 dark:text-slate-400"
            >
              {t.cancel}
            </button>
            <button
              onClick={handleApply}
              className="px-4 py-1.5 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl shadow-xs transition flex items-center gap-1"
            >
              <Check className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'প্রয়োগ করুন' : 'Apply'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
