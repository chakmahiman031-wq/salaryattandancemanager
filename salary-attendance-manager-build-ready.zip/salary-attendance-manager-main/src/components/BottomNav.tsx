import React from 'react';
import { Home, Calendar, FileSpreadsheet, History, Settings } from 'lucide-react';
import { NavigationTab, AppLanguage } from '../types';
import { translations } from '../locales/translations';

interface BottomNavProps {
  activeTab: NavigationTab;
  onSelectTab: (tab: NavigationTab) => void;
  language: AppLanguage;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onSelectTab,
  language,
}) => {
  const t = translations[language];

  const tabs: { id: NavigationTab; label: string; icon: React.ReactNode }[] = [
    { id: 'home', label: t.navHome, icon: <Home className="w-5 h-5" /> },
    { id: 'calendar', label: t.navCalendar, icon: <Calendar className="w-5 h-5" /> },
    { id: 'summary', label: t.navSummary, icon: <FileSpreadsheet className="w-5 h-5" /> },
    { id: 'history', label: t.navHistory, icon: <History className="w-5 h-5" /> },
    { id: 'settings', label: t.navSettings, icon: <Settings className="w-5 h-5" /> },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 transition-colors">
      <div className="max-w-md sm:max-w-xl mx-auto flex items-center justify-around px-2 py-1.5">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              id={`nav-btn-${tab.id}`}
              onClick={() => onSelectTab(tab.id)}
              className={`flex-1 flex flex-col items-center justify-center py-1.5 px-2 rounded-xl transition-all duration-150 min-h-[48px] ${
                isActive
                  ? 'text-emerald-600 dark:text-emerald-400 font-bold scale-102'
                  : 'text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 font-medium'
              }`}
            >
              <div className={`p-1 rounded-full transition-colors ${
                isActive ? 'bg-emerald-50 dark:bg-emerald-950/60' : ''
              }`}>
                {tab.icon}
              </div>
              <span className="text-[11px] tracking-tight leading-none mt-1">
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
