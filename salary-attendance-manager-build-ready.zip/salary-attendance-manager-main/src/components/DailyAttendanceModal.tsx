import React, { useState, useEffect } from 'react';
import { X, Check, Clock, AlertCircle, Calendar } from 'lucide-react';
import { AttendanceStatus, AppLanguage } from '../types';
import { translations } from '../locales/translations';
import { toBengaliNumerals } from '../services/calculationEngine';

interface DailyAttendanceModalProps {
  isOpen: boolean;
  onClose: () => void;
  year: number;
  month: number;
  date: number;
  currentStatus: AttendanceStatus;
  currentOtHours: number;
  onSave: (date: number, status: AttendanceStatus, otHours: number) => void;
  language: AppLanguage;
}

export const DailyAttendanceModal: React.FC<DailyAttendanceModalProps> = ({
  isOpen,
  onClose,
  year,
  month,
  date,
  currentStatus,
  currentOtHours,
  onSave,
  language,
}) => {
  const t = translations[language];

  const [selectedStatus, setSelectedStatus] = useState<AttendanceStatus>(currentStatus);
  const [otHoursInput, setOtHoursInput] = useState<string>(
    currentOtHours > 0 ? String(currentOtHours) : ''
  );
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    setSelectedStatus(currentStatus);
    setOtHoursInput(currentOtHours > 0 ? String(currentOtHours) : '');
    setErrorMessage(null);
  }, [currentStatus, currentOtHours, date, month, year, isOpen]);

  if (!isOpen) return null;

  // Day of week calculation
  const dateObj = new Date(year, month - 1, date);
  const dayOfWeekIndex = dateObj.getDay();
  const dayName = t.fullDayNames[dayOfWeekIndex];
  const monthName = t.monthNames[month - 1];
  const displayDate = language === 'bn' ? toBengaliNumerals(date) : date;
  const displayYear = language === 'bn' ? toBengaliNumerals(year) : year;

  const handleStatusClick = (status: AttendanceStatus) => {
    setSelectedStatus(status);
    const parsedOt = parseFloat(otHoursInput) || 0;
    onSave(date, status, Math.max(0, parsedOt));
  };

  const handleOtChange = (val: string) => {
    // Allow digits and single decimal point
    if (val === '' || /^\d*\.?\d*$/.test(val)) {
      setOtHoursInput(val);
      const parsed = parseFloat(val);
      if (val !== '' && (isNaN(parsed) || parsed < 0)) {
        setErrorMessage(t.valPositiveNumbers);
      } else {
        setErrorMessage(null);
        onSave(date, selectedStatus, Math.max(0, parsed || 0));
      }
    }
  };

  const handleQuickOtPreset = (hours: number) => {
    setOtHoursInput(String(hours));
    setErrorMessage(null);
    onSave(date, selectedStatus, hours);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/60 dark:bg-slate-900/60">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                {displayDate} {monthName}, {displayYear}
              </h3>
              <p className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                {dayName}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-6">
          {/* Section 1: Attendance Status Selection */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                {t.selectAttendance}
              </label>
              <span className="text-xs font-medium text-slate-400 dark:text-slate-500">
                {t.currentStatus}:{' '}
                <strong className="text-slate-700 dark:text-slate-300">
                  {selectedStatus === 'PRESENT'
                    ? t.statusPresent
                    : selectedStatus === 'ABSENT'
                    ? t.statusAbsent
                    : selectedStatus === 'LEAVE'
                    ? t.statusLeave
                    : t.statusNotMarked}
                </strong>
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              {/* PRESENT Button */}
              <button
                id="btn-mark-present"
                onClick={() => handleStatusClick('PRESENT')}
                className={`py-3 px-3 rounded-xl border flex items-center justify-center gap-2 text-sm font-bold transition ${
                  selectedStatus === 'PRESENT'
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm shadow-emerald-600/30'
                    : 'bg-emerald-50/50 hover:bg-emerald-100/70 dark:bg-emerald-950/30 dark:hover:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800/60'
                }`}
              >
                <div className={`w-3 h-3 rounded-full ${selectedStatus === 'PRESENT' ? 'bg-white' : 'bg-emerald-500'}`} />
                <span>{t.statusPresent}</span>
                {selectedStatus === 'PRESENT' && <Check className="w-4 h-4 ml-auto" />}
              </button>

              {/* ABSENT Button */}
              <button
                id="btn-mark-absent"
                onClick={() => handleStatusClick('ABSENT')}
                className={`py-3 px-3 rounded-xl border flex items-center justify-center gap-2 text-sm font-bold transition ${
                  selectedStatus === 'ABSENT'
                    ? 'bg-rose-600 text-white border-rose-600 shadow-sm shadow-rose-600/30'
                    : 'bg-rose-50/50 hover:bg-rose-100/70 dark:bg-rose-950/30 dark:hover:bg-rose-950/60 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800/60'
                }`}
              >
                <div className={`w-3 h-3 rounded-full ${selectedStatus === 'ABSENT' ? 'bg-white' : 'bg-rose-500'}`} />
                <span>{t.statusAbsent}</span>
                {selectedStatus === 'ABSENT' && <Check className="w-4 h-4 ml-auto" />}
              </button>

              {/* LEAVE Button */}
              <button
                id="btn-mark-leave"
                onClick={() => handleStatusClick('LEAVE')}
                className={`py-3 px-3 rounded-xl border flex items-center justify-center gap-2 text-sm font-bold transition ${
                  selectedStatus === 'LEAVE'
                    ? 'bg-amber-500 text-white border-amber-500 shadow-sm shadow-amber-500/30'
                    : 'bg-amber-50/50 hover:bg-amber-100/70 dark:bg-amber-950/30 dark:hover:bg-amber-950/60 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800/60'
                }`}
              >
                <div className={`w-3 h-3 rounded-full ${selectedStatus === 'LEAVE' ? 'bg-white' : 'bg-amber-500'}`} />
                <span>{t.statusLeave}</span>
                {selectedStatus === 'LEAVE' && <Check className="w-4 h-4 ml-auto" />}
              </button>

              {/* CLEAR / NOT MARKED Button */}
              <button
                id="btn-mark-clear"
                onClick={() => handleStatusClick('NOT_MARKED')}
                className={`py-3 px-3 rounded-xl border flex items-center justify-center gap-2 text-sm font-semibold transition ${
                  selectedStatus === 'NOT_MARKED'
                    ? 'bg-slate-700 text-white border-slate-700 dark:bg-slate-600'
                    : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                }`}
              >
                <div className="w-3 h-3 rounded-full bg-slate-400" />
                <span>{t.clearStatus}</span>
                {selectedStatus === 'NOT_MARKED' && <Check className="w-4 h-4 ml-auto" />}
              </button>
            </div>
          </div>

          {/* Section 2: Overtime (OT) Hours Input */}
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <label htmlFor="input-ot-hours" className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span>{t.otHoursLabel}</span>
              </label>
              <span className="text-xs text-slate-400">
                {language === 'bn' ? 'দশমিক সমর্থিত (যেমন: ১.৫, ২.৫)' : 'Decimals allowed (e.g. 1.5, 2.5)'}
              </span>
            </div>

            <div className="relative">
              <input
                id="input-ot-hours"
                type="text"
                inputMode="decimal"
                value={otHoursInput}
                onChange={(e) => handleOtChange(e.target.value)}
                placeholder="0"
                className="w-full px-4 py-2.5 text-base font-semibold bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
              />
              <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">
                {t.hoursShort}
              </span>
            </div>

            {errorMessage && (
              <p className="mt-1.5 text-xs text-rose-500 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>{errorMessage}</span>
              </p>
            )}

            {/* Quick OT Presets */}
            <div className="mt-3 flex items-center flex-wrap gap-1.5">
              <span className="text-[11px] font-medium text-slate-400 mr-1">
                {t.otQuickPreset}:
              </span>
              {[0, 1, 1.5, 2, 2.5, 3, 4, 5].map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => handleQuickOtPreset(preset)}
                  className={`px-2.5 py-1 text-xs font-bold rounded-lg border transition ${
                    parseFloat(otHoursInput) === preset
                      ? 'bg-emerald-600 text-white border-emerald-600'
                      : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {language === 'bn' ? toBengaliNumerals(preset) : preset}h
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3.5 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <span className="text-xs text-emerald-600 dark:text-emerald-400 font-medium flex items-center gap-1">
            <Check className="w-3.5 h-3.5" />
            <span>{t.autoSaved}</span>
          </span>
          <button
            id="btn-close-daily-modal"
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl shadow-xs transition"
          >
            {t.saveClose}
          </button>
        </div>
      </div>
    </div>
  );
};
