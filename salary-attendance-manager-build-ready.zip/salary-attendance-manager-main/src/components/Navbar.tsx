import React from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Calendar as CalendarIcon, 
  Download, 
  Moon, 
  Sun, 
  Monitor, 
  Globe 
} from 'lucide-react';
import { AppLanguage, AppTheme } from '../types';
import { translations } from '../locales/translations';
import { toBengaliNumerals } from '../services/calculationEngine';

interface NavbarProps {
  currentYear: number;
  currentMonth: number;
  onMonthChange: (year: number, month: number) => void;
  language: AppLanguage;
  onLanguageChange: (lang: AppLanguage) => void;
  theme: AppTheme;
  onThemeChange: (theme: AppTheme) => void;
  onOpenMonthPicker: () => void;
  onDownloadAndroidZip: () => void;
  isDownloadingZip: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentYear,
  currentMonth,
  onMonthChange,
  language,
  onLanguageChange,
  theme,
  onThemeChange,
  onOpenMonthPicker,
  onDownloadAndroidZip,
  isDownloadingZip,
}) => {
  const t = translations[language];

  const handlePrevMonth = () => {
    if (currentMonth === 1) {
      onMonthChange(currentYear - 1, 12);
    } else {
      onMonthChange(currentYear, currentMonth - 1);
    }
  };

  const handleNextMonth = () => {
    if (currentMonth === 12) {
      onMonthChange(currentYear + 1, 1);
    } else {
      onMonthChange(currentYear, currentMonth + 1);
    }
  };

  const monthName = t.monthNames[currentMonth - 1];
  const displayYear = language === 'bn' ? toBengaliNumerals(currentYear) : currentYear;

  return (
    <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 transition-colors">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-2.5 flex items-center justify-between gap-3">
        {/* Brand & Logo */}
        <div className="flex items-center gap-2.5 min-w-0">
          <img 
            src="/logo.jpg" 
            alt="App Logo" 
            className="w-10 h-10 rounded-xl object-cover shadow-sm ring-1 ring-emerald-500/20 shrink-0" 
            onError={(e) => {
              (e.target as HTMLElement).style.display = 'none';
            }}
          />
          <div className="truncate">
            <h1 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white leading-tight truncate">
              {t.appName}
            </h1>
            <p className="text-[11px] font-medium text-emerald-600 dark:text-emerald-400 truncate">
              {t.appSubtitle}
            </p>
          </div>
        </div>

        {/* Month Navigator Controls */}
        <div className="flex items-center bg-slate-100 dark:bg-slate-800/80 rounded-xl p-1 border border-slate-200/60 dark:border-slate-700/60 shadow-xs">
          <button
            id="btn-prev-month"
            onClick={handlePrevMonth}
            className="p-1.5 hover:bg-white dark:hover:bg-slate-700 rounded-lg text-slate-600 dark:text-slate-300 transition"
            title={t.prevMonth}
            aria-label={t.prevMonth}
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <button
            id="btn-month-picker-toggle"
            onClick={onOpenMonthPicker}
            className="px-2.5 py-1 text-xs sm:text-sm font-semibold text-slate-800 dark:text-slate-100 flex items-center gap-1.5 hover:bg-white dark:hover:bg-slate-700 rounded-lg transition"
            title={t.selectMonthYear}
          >
            <CalendarIcon className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span>{monthName} {displayYear}</span>
          </button>

          <button
            id="btn-next-month"
            onClick={handleNextMonth}
            className="p-1.5 hover:bg-white dark:hover:bg-slate-700 rounded-lg text-slate-600 dark:text-slate-300 transition"
            title={t.nextMonth}
            aria-label={t.nextMonth}
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Action Controls: Language, Theme, Download ZIP */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Language Toggle */}
          <button
            id="btn-toggle-language"
            onClick={() => onLanguageChange(language === 'bn' ? 'en' : 'bn')}
            className="px-2 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition flex items-center gap-1"
            title="Switch Language / ভাষা পরিবর্তন"
          >
            <Globe className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span className="font-bold">{language === 'bn' ? 'EN' : 'বাং'}</span>
          </button>

          {/* Theme Toggle */}
          <button
            id="btn-toggle-theme"
            onClick={() => {
              const nextTheme: AppTheme = theme === 'system' ? 'dark' : theme === 'dark' ? 'light' : 'system';
              onThemeChange(nextTheme);
            }}
            className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            title={`Theme: ${theme}`}
            aria-label="Toggle Theme"
          >
            {theme === 'dark' ? (
              <Moon className="w-4 h-4 text-amber-400" />
            ) : theme === 'light' ? (
              <Sun className="w-4 h-4 text-amber-500" />
            ) : (
              <Monitor className="w-4 h-4 text-emerald-500" />
            )}
          </button>

          {/* Android Project Download Button */}
          <button
            id="btn-download-android-apk-zip"
            onClick={onDownloadAndroidZip}
            disabled={isDownloadingZip}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white text-xs font-semibold shadow-sm transition disabled:opacity-50"
            title={t.downloadAndroidDesc}
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isDownloadingZip ? t.generatingZip : 'Android Project (.zip)'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
