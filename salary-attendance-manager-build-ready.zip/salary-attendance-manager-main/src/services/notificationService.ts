/**
 * Attendance Notification & Reminder Service
 */

import { AppLanguage } from '../types';
import { translations } from '../locales/translations';

class NotificationServiceImpl {
  private reminderInterval: any = null;

  async requestPermission(): Promise<NotificationPermission> {
    if (!('Notification' in window)) {
      return 'denied';
    }
    try {
      return await Notification.requestPermission();
    } catch (e) {
      console.warn('Could not request notification permission', e);
      return 'denied';
    }
  }

  isSupported(): boolean {
    return 'Notification' in window;
  }

  getPermissionState(): NotificationPermission {
    if (!('Notification' in window)) return 'denied';
    return Notification.permission;
  }

  triggerReminderNotification(lang: AppLanguage = 'bn'): boolean {
    const t = translations[lang];
    const title = t.appName;
    const body = lang === 'bn' ? t.reminderBengaliText : t.reminderEnglishText;

    if (this.isSupported() && Notification.permission === 'granted') {
      try {
        new Notification(title, {
          body,
          icon: '/logo.jpg',
          badge: '/logo.jpg',
        });
        return true;
      } catch (e) {
        console.warn('Notification constructor failed', e);
      }
    }
    return false;
  }

  triggerMonthlySummaryNotification(lang: AppLanguage = 'bn'): boolean {
    const t = translations[lang];
    const title = t.appName;
    const body = t.monthlyReminderText;

    if (this.isSupported() && Notification.permission === 'granted') {
      try {
        new Notification(title, {
          body,
          icon: '/logo.jpg',
        });
        return true;
      } catch (e) {
        console.warn('Notification constructor failed', e);
      }
    }
    return false;
  }
  async showAttendanceReminder(title: string, body: string): Promise<boolean> {
    if (!this.isSupported()) return false;
    let perm = Notification.permission;
    if (perm !== 'granted') {
      perm = await this.requestPermission();
    }
    if (perm === 'granted') {
      try {
        new Notification(title, {
          body,
          icon: '/logo.jpg',
        });
        return true;
      } catch (e) {
        console.warn('Could not display notification', e);
      }
    }
    return false;
  }

  scheduleDailyReminder(reminderTime: string, title: string, body: string): () => void {
    if (this.reminderInterval) {
      clearInterval(this.reminderInterval);
      this.reminderInterval = null;
    }

    // Check once every 30 seconds
    const interval = setInterval(() => {
      const now = new Date();
      const currentHours = String(now.getHours()).padStart(2, '0');
      const currentMinutes = String(now.getMinutes()).padStart(2, '0');
      const currentFormatted = `${currentHours}:${currentMinutes}`;

      if (currentFormatted === reminderTime && now.getSeconds() < 30) {
        this.showAttendanceReminder(title, body);
      }
    }, 30000);

    this.reminderInterval = interval;
    return () => clearInterval(interval);
  }
}

export const notificationService = new NotificationServiceImpl();
export const NotificationService = notificationService;
