/**
 * Offline-first persistent storage service
 * Manages MonthlySalarySettings, Attendance, DailyOT, and UserSettings
 */

import { MonthlySalarySettings, AttendanceRecord, DailyOTRecord, UserSettings } from '../types';

const STORAGE_KEYS = {
  USER_SETTINGS: 'sam_user_settings_v1',
  MONTHLY_SETTINGS: 'sam_monthly_settings_v1',
  ATTENDANCE: 'sam_attendance_v1',
  DAILY_OT: 'sam_daily_ot_v1',
};

// Default User Settings (Default language: Bengali বাংলা as specified)
const DEFAULT_USER_SETTINGS: UserSettings = {
  language: 'bn',
  theme: 'system',
  currency: '৳',
  reminderEnabled: true,
  reminderTime: '21:00',
  isFirstTimeSetupCompleted: false,
};

// Default Base Template for Salary Settings (Matching prompt examples)
export function createDefaultMonthlySettings(year: number, month: number): MonthlySalarySettings {
  return {
    id: `settings_${year}_${month}`,
    year,
    month,
    basicSalary: 20000,
    transportAllowance: 3000,
    foodAllowance: 2000,
    attendanceBonus: 2000,
    workingDays: 26,
    otRate: 100,
    deductTransportOnAbsent: false,
    deductFoodOnAbsent: false,
    leaveAffectsBonus: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

class StorageServiceImpl {
  private userSettingsCache: UserSettings | null = null;

  // --- User Settings ---
  getUserSettings(): UserSettings {
    if (this.userSettingsCache) return this.userSettingsCache;
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.USER_SETTINGS);
      if (stored) {
        this.userSettingsCache = { ...DEFAULT_USER_SETTINGS, ...JSON.parse(stored) };
        return this.userSettingsCache;
      }
    } catch (e) {
      console.error('Failed to load user settings from localStorage', e);
    }
    this.userSettingsCache = { ...DEFAULT_USER_SETTINGS };
    return this.userSettingsCache;
  }

  saveUserSettings(settings: Partial<UserSettings>): UserSettings {
    const current = this.getUserSettings();
    const updated = { ...current, ...settings };
    this.userSettingsCache = updated;
    try {
      localStorage.setItem(STORAGE_KEYS.USER_SETTINGS, JSON.stringify(updated));
    } catch (e) {
      console.error('Failed to save user settings', e);
    }
    return updated;
  }

  // --- Monthly Salary Settings ---
  getAllMonthlySettingsMap(): Record<string, MonthlySalarySettings> {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.MONTHLY_SETTINGS);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.error('Failed to parse monthly settings', e);
    }
    return {};
  }

  getAllMonthlySettings(): MonthlySalarySettings[] {
    const map = this.getAllMonthlySettingsMap();
    return Object.values(map);
  }

  getMonthlySettings(year: number, month: number): MonthlySalarySettings {
    const all = this.getAllMonthlySettingsMap();
    const key = `${year}_${month}`;
    if (all[key]) {
      return all[key];
    }

    // If not found for this specific month, look for the most recent month before this
    const previous = this.findMostRecentSettingsBefore(year, month);
    if (previous) {
      // Inherit salary configuration numbers, but assign to current month
      const inherited: MonthlySalarySettings = {
        ...previous,
        id: `settings_${year}_${month}`,
        year,
        month,
        updatedAt: new Date().toISOString(),
      };
      this.saveMonthlySettings(inherited);
      return inherited;
    }

    // Default template
    const def = createDefaultMonthlySettings(year, month);
    this.saveMonthlySettings(def);
    return def;
  }

  saveMonthlySettings(settings: MonthlySalarySettings): void {
    const all = this.getAllMonthlySettingsMap();
    const key = `${settings.year}_${settings.month}`;
    all[key] = {
      ...settings,
      updatedAt: new Date().toISOString(),
    };
    try {
      localStorage.setItem(STORAGE_KEYS.MONTHLY_SETTINGS, JSON.stringify(all));
    } catch (e) {
      console.error('Failed to persist monthly settings', e);
    }
  }

  /**
   * "Copy Previous Month Settings"
   * Copies ONLY salary configuration. MUST NOT copy attendance records!
   */
  copyPreviousMonthSettings(targetYear: number, targetMonth: number): MonthlySalarySettings | null {
    const previous = this.findMostRecentSettingsBefore(targetYear, targetMonth);
    if (!previous) return null;

    const copied: MonthlySalarySettings = {
      ...previous,
      id: `settings_${targetYear}_${targetMonth}`,
      year: targetYear,
      month: targetMonth,
      updatedAt: new Date().toISOString(),
    };

    this.saveMonthlySettings(copied);
    return copied;
  }

  private findMostRecentSettingsBefore(targetYear: number, targetMonth: number): MonthlySalarySettings | null {
    const all = this.getAllMonthlySettingsMap();
    const keys = Object.keys(all);
    if (keys.length === 0) return null;

    // Check previous month directly first (month - 1)
    let prevYear = targetYear;
    let prevMonth = targetMonth - 1;
    if (prevMonth < 1) {
      prevMonth = 12;
      prevYear -= 1;
    }
    const directKey = `${prevYear}_${prevMonth}`;
    if (all[directKey]) return all[directKey];

    // Otherwise find closest earlier month
    let bestKey: string | null = null;
    let bestScore = -1;
    const targetScore = targetYear * 12 + targetMonth;

    for (const key of keys) {
      const item = all[key];
      const score = item.year * 12 + item.month;
      if (score < targetScore && score > bestScore) {
        bestScore = score;
        bestKey = key;
      }
    }

    return bestKey ? all[bestKey] : null;
  }

  // --- Attendance ---
  private getAllAttendance(): Record<string, AttendanceRecord[]> {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.ATTENDANCE);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.error('Failed to parse attendance records', e);
    }
    return {};
  }

  getAttendanceForMonth(year: number, month: number): AttendanceRecord[] {
    const all = this.getAllAttendance();
    const key = `${year}_${month}`;
    return all[key] || [];
  }

  setAttendance(year: number, month: number, date: number, status: AttendanceRecord['status']): void {
    const all = this.getAllAttendance();
    const key = `${year}_${month}`;
    let list = all[key] || [];

    // Remove existing record for this date if any
    list = list.filter((item) => item.date !== date);

    // If status is NOT_MARKED, simply removing is sufficient, but we can store explicit or omit
    if (status !== 'NOT_MARKED') {
      list.push({
        id: `att_${year}_${month}_${date}`,
        year,
        month,
        date,
        status,
        updatedAt: new Date().toISOString(),
      });
    }

    all[key] = list;
    try {
      localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(all));
    } catch (e) {
      console.error('Failed to save attendance', e);
    }
  }

  // --- Daily OT ---
  private getAllDailyOT(): Record<string, DailyOTRecord[]> {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.DAILY_OT);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.error('Failed to parse daily OT records', e);
    }
    return {};
  }

  getDailyOTForMonth(year: number, month: number): DailyOTRecord[] {
    const all = this.getAllDailyOT();
    const key = `${year}_${month}`;
    return all[key] || [];
  }

  getDailyOtForMonth(year: number, month: number): DailyOTRecord[] {
    return this.getDailyOTForMonth(year, month);
  }

  saveAttendanceRecord(record: AttendanceRecord): void {
    this.setAttendance(record.year, record.month, record.date, record.status);
  }

  saveDailyOtRecord(record: DailyOTRecord): void {
    this.setDailyOT(record.year, record.month, record.date, record.otHours);
  }

  setDailyOT(year: number, month: number, date: number, otHours: number): void {
    const all = this.getAllDailyOT();
    const key = `${year}_${month}`;
    let list = all[key] || [];

    // Filter out existing date
    list = list.filter((item) => item.date !== date);

    if (otHours > 0) {
      list.push({
        id: `ot_${year}_${month}_${date}`,
        year,
        month,
        date,
        otHours: Math.max(0, Math.round(otHours * 100) / 100),
        updatedAt: new Date().toISOString(),
      });
    }

    all[key] = list;
    try {
      localStorage.setItem(STORAGE_KEYS.DAILY_OT, JSON.stringify(all));
    } catch (e) {
      console.error('Failed to save daily OT', e);
    }
  }

  // --- Recorded Months Discovery for History ---
  getAllRecordedMonths(): { year: number; month: number }[] {
    const monthsSet = new Set<string>();

    const allSettings = this.getAllMonthlySettingsMap();
    for (const s of Object.values(allSettings)) {
      monthsSet.add(`${s.year}_${s.month}`);
    }

    const allAttendance = this.getAllAttendance();
    for (const key of Object.keys(allAttendance)) {
      if (allAttendance[key]?.length > 0) {
        monthsSet.add(key);
      }
    }

    const allOT = this.getAllDailyOT();
    for (const key of Object.keys(allOT)) {
      if (allOT[key]?.length > 0) {
        monthsSet.add(key);
      }
    }

    // Always include current month
    const now = new Date();
    monthsSet.add(`${now.getFullYear()}_${now.getMonth() + 1}`);

    const list = Array.from(monthsSet).map((key) => {
      const [y, m] = key.split('_').map(Number);
      return { year: y, month: m };
    });

    // Sort descending (latest month first)
    list.sort((a, b) => (b.year * 12 + b.month) - (a.year * 12 + a.month));
    return list;
  }

  // --- Reset All Data ---
  resetAllData(): void {
    try {
      localStorage.removeItem(STORAGE_KEYS.MONTHLY_SETTINGS);
      localStorage.removeItem(STORAGE_KEYS.ATTENDANCE);
      localStorage.removeItem(STORAGE_KEYS.DAILY_OT);
      
      // Reset user settings back to default
      this.userSettingsCache = { ...DEFAULT_USER_SETTINGS, isFirstTimeSetupCompleted: false };
      localStorage.setItem(STORAGE_KEYS.USER_SETTINGS, JSON.stringify(this.userSettingsCache));
    } catch (e) {
      console.error('Failed to reset all data', e);
    }
  }

  clearAllData(): void {
    this.resetAllData();
  }
}

export const storageService = new StorageServiceImpl();
export const StorageService = storageService;

