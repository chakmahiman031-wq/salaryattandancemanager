/**
 * Centralized Salary & Attendance Calculation Engine
 * 
 * Implements strict rules specified in sections 9 - 20:
 * - Basic Salary calculation & absent deductions
 * - Attendance bonus rules with leave dependency toggle
 * - Transport allowance & conditional absent deduction
 * - Food allowance & conditional absent deduction
 * - Decimal Overtime (OT) pay calculation
 * - Final expected salary aggregation
 */

import { MonthlySalarySettings, SalaryCalculationResult, AttendanceRecord, DailyOTRecord } from '../types';

/**
 * Rounds a number to exactly 2 decimal places using standard financial rounding
 */
export function round2(val: number): number {
  return Math.round((val + Number.EPSILON) * 100) / 100;
}

/**
 * Formats a currency number with BDT symbol (৳) and standard commas
 * e.g. 25230.77 -> "৳25,230.77" or "৳20,000"
 */
export function formatCurrency(amount: number, currencySymbol: string = '৳'): string {
  const rounded = round2(amount);
  const isNegative = rounded < 0;
  const absVal = Math.abs(rounded);
  
  // Format with commas
  const parts = absVal.toFixed(2).split('.');
  const integerPart = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  const formatted = parts[1] === '00' ? integerPart : `${integerPart}.${parts[1]}`;
  
  return isNegative ? `-${currencySymbol}${formatted}` : `${currencySymbol}${formatted}`;
}

/**
 * Formats numbers in Bengali numerals (০-৯)
 */
export function toBengaliNumerals(numStr: string | number): string {
  const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return String(numStr).replace(/[0-9]/g, (digit) => bnDigits[parseInt(digit, 10)]);
}

/**
 * Returns total days in a given month handling leap years for February
 */
export function getDaysInMonth(year: number, month: number): number {
  return new Date(year, month, 0).getDate();
}

/**
 * Central calculation engine function
 */
export function calculateSalary(
  settings: MonthlySalarySettings,
  attendanceRecords: AttendanceRecord[],
  otRecords: DailyOTRecord[]
): SalaryCalculationResult {
  const totalDaysInMonth = getDaysInMonth(settings.year, settings.month);

  // Validate working days (prevent division by zero or negative)
  const workingDays = Math.max(1, settings.workingDays || 26);
  const basicSalary = Math.max(0, settings.basicSalary || 0);
  const transportAllowance = Math.max(0, settings.transportAllowance || 0);
  const foodAllowance = Math.max(0, settings.foodAllowance || 0);
  const attendanceBonusConfig = Math.max(0, settings.attendanceBonus || 0);
  const otRate = Math.max(0, settings.otRate || 0);

  // Count attendance stats
  let presentDays = 0;
  let absentDays = 0;
  let leaveDays = 0;
  let markedCount = 0;

  // Build map of recorded attendance by date
  const attendanceMap = new Map<number, string>();
  for (const record of attendanceRecords) {
    if (record.date >= 1 && record.date <= totalDaysInMonth) {
      attendanceMap.set(record.date, record.status);
    }
  }

  for (let d = 1; d <= totalDaysInMonth; d++) {
    const status = attendanceMap.get(d) || 'NOT_MARKED';
    if (status === 'PRESENT') {
      presentDays++;
      markedCount++;
    } else if (status === 'ABSENT') {
      absentDays++;
      markedCount++;
    } else if (status === 'LEAVE') {
      leaveDays++;
      markedCount++;
    }
  }

  const notMarkedDays = totalDaysInMonth - markedCount;

  // 1. Basic Salary Calculations
  // Daily Basic Salary = Basic Monthly Salary ÷ Working Days
  const rawDailyBasic = basicSalary / workingDays;
  const dailyBasicSalary = round2(rawDailyBasic);
  
  // Basic Deduction = Absent Days × Daily Basic Salary
  const basicDeduction = round2(absentDays * dailyBasicSalary);
  
  // Basic Earned = Basic Salary - Basic Deduction (cannot be negative)
  const basicEarnedSalary = Math.max(0, round2(basicSalary - basicDeduction));

  // 2. Attendance Bonus
  // Strict rule:
  // If Leave Affects Bonus = YES: If Absent > 0 OR Leave > 0 => Bonus = 0, else Full Bonus
  // If Leave Affects Bonus = NO: If Absent > 0 => Bonus = 0, else Full Bonus
  let attendanceBonus = 0;
  let bonusForfeitedReason: string | undefined = undefined;

  if (settings.leaveAffectsBonus) {
    if (absentDays > 0) {
      attendanceBonus = 0;
      bonusForfeitedReason = 'ABSENT_DAYS';
    } else if (leaveDays > 0) {
      attendanceBonus = 0;
      bonusForfeitedReason = 'LEAVE_DAYS';
    } else {
      attendanceBonus = round2(attendanceBonusConfig);
    }
  } else {
    if (absentDays > 0) {
      attendanceBonus = 0;
      bonusForfeitedReason = 'ABSENT_DAYS';
    } else {
      attendanceBonus = round2(attendanceBonusConfig);
    }
  }

  // 3. Transport Allowance
  let dailyTransport = 0;
  let transportDeduction = 0;
  let transportEarned = transportAllowance;

  if (settings.deductTransportOnAbsent) {
    const rawDailyTransport = transportAllowance / workingDays;
    dailyTransport = round2(rawDailyTransport);
    transportDeduction = round2(absentDays * dailyTransport);
    transportEarned = Math.max(0, round2(transportAllowance - transportDeduction));
  } else {
    dailyTransport = 0;
    transportDeduction = 0;
    transportEarned = round2(transportAllowance);
  }

  // 4. Food Allowance
  let dailyFood = 0;
  let foodDeduction = 0;
  let foodEarned = foodAllowance;

  if (settings.deductFoodOnAbsent) {
    const rawDailyFood = foodAllowance / workingDays;
    dailyFood = round2(rawDailyFood);
    foodDeduction = round2(absentDays * dailyFood);
    foodEarned = Math.max(0, round2(foodAllowance - foodDeduction));
  } else {
    dailyFood = 0;
    foodDeduction = 0;
    foodEarned = round2(foodAllowance);
  }

  // 5. Overtime (OT)
  let totalOtHours = 0;
  for (const ot of otRecords) {
    if (ot.date >= 1 && ot.date <= totalDaysInMonth && ot.otHours > 0) {
      totalOtHours += ot.otHours;
    }
  }
  totalOtHours = round2(totalOtHours);
  const otPay = round2(totalOtHours * otRate);

  // Total deductions
  const totalDeductions = round2(basicDeduction + transportDeduction + foodDeduction);

  // 6. Final Expected Salary
  // Basic Earned + Transport Earned + Food Earned + Attendance Bonus + OT Pay
  const finalExpectedSalary = round2(
    basicEarnedSalary + transportEarned + foodEarned + attendanceBonus + otPay
  );

  return {
    basicSalary,
    workingDays,
    transportAllowance,
    foodAllowance,
    attendanceBonusConfig,
    otRate,
    totalDaysInMonth,
    presentDays,
    absentDays,
    leaveDays,
    notMarkedDays,
    dailyBasicSalary,
    basicDeduction,
    basicEarnedSalary,
    dailyTransport,
    transportDeduction,
    transportEarned,
    dailyFood,
    foodDeduction,
    foodEarned,
    attendanceBonus,
    bonusForfeitedReason,
    totalOtHours,
    otPay,
    totalDeductions,
    finalExpectedSalary,
  };
}

/**
 * Built-in verification checks for user specification test cases 1 to 4
 */
export function verifyCalculationTestCases(): boolean {
  const baseSettings: MonthlySalarySettings = {
    id: 'test_1',
    year: 2026,
    month: 9, // September (30 days)
    basicSalary: 20000,
    transportAllowance: 3000,
    foodAllowance: 2000,
    attendanceBonus: 2000,
    workingDays: 26,
    otRate: 100,
    deductTransportOnAbsent: false,
    deductFoodOnAbsent: false,
    leaveAffectsBonus: false,
  };

  // Test 1: Absent = 0, OT = 0 -> Total = 27,000
  const r1 = calculateSalary(baseSettings, [], []);
  const pass1 = r1.basicEarnedSalary === 20000 &&
                r1.transportEarned === 3000 &&
                r1.foodEarned === 2000 &&
                r1.attendanceBonus === 2000 &&
                r1.otPay === 0 &&
                r1.finalExpectedSalary === 27000;

  // Test 2: Absent = 1, OT = 0 -> Daily = 769.23, Basic = 19230.77, Bonus = 0, Total = 24,230.77
  const absentRecords: AttendanceRecord[] = [
    { id: 'a1', year: 2026, month: 9, date: 1, status: 'ABSENT' },
  ];
  const r2 = calculateSalary(baseSettings, absentRecords, []);
  const pass2 = r2.dailyBasicSalary === 769.23 &&
                r2.basicDeduction === 769.23 &&
                r2.basicEarnedSalary === 19230.77 &&
                r2.attendanceBonus === 0 &&
                r2.finalExpectedSalary === 24230.77;

  // Test 3: Absent = 0, OT = 10 -> OT Pay = 1000, Total = 28,000
  const otRecords10: DailyOTRecord[] = [
    { id: 'o1', year: 2026, month: 9, date: 5, otHours: 2 },
    { id: 'o2', year: 2026, month: 9, date: 8, otHours: 3 },
    { id: 'o3', year: 2026, month: 9, date: 10, otHours: 5 },
  ];
  const r3 = calculateSalary(baseSettings, [], otRecords10);
  const pass3 = r3.totalOtHours === 10 &&
                r3.otPay === 1000 &&
                r3.finalExpectedSalary === 28000;

  // Test 4: Absent = 1, OT = 10 -> Basic = 19230.77, Bonus = 0, OT = 1000, Total = 25,230.77
  const r4 = calculateSalary(baseSettings, absentRecords, otRecords10);
  const pass4 = r4.basicEarnedSalary === 19230.77 &&
                r4.attendanceBonus === 0 &&
                r4.otPay === 1000 &&
                r4.finalExpectedSalary === 25230.77;

  return pass1 && pass2 && pass3 && pass4;
}

export const calculateMonthlySalary = calculateSalary;
