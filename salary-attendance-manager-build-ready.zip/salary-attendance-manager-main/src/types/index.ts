/**
 * Salary & Attendance Manager - Type Definitions
 */

export type AttendanceStatus = 'PRESENT' | 'ABSENT' | 'LEAVE' | 'NOT_MARKED';

export interface MonthlySalarySettings {
  id: string;
  year: number;
  month: number; // 1-12
  basicSalary: number; // ৳ Monthly basic
  transportAllowance: number; // ৳ Transport / Car allowance
  foodAllowance: number; // ৳ Food allowance
  attendanceBonus: number; // ৳ Full attendance bonus
  workingDays: number; // e.g. 26
  otRate: number; // ৳ OT rate per hour
  deductTransportOnAbsent: boolean; // Deduct transport when absent
  deductFoodOnAbsent: boolean; // Deduct food when absent
  leaveAffectsBonus: boolean; // If true, leave also forfeits attendance bonus
  createdAt?: string;
  updatedAt?: string;
}

export interface AttendanceRecord {
  id: string;
  year: number;
  month: number;
  date: number; // 1-31
  status: AttendanceStatus;
  updatedAt?: string;
}

export interface DailyOTRecord {
  id: string;
  year: number;
  month: number;
  date: number; // 1-31
  otHours: number; // >= 0, can be decimal e.g. 1.5
  updatedAt?: string;
}

export type AppLanguage = 'bn' | 'en';
export type AppTheme = 'system' | 'light' | 'dark';

export interface UserSettings {
  language: AppLanguage;
  theme: AppTheme;
  currency: string;
  reminderEnabled: boolean;
  reminderTime: string; // e.g. "21:00"
  isFirstTimeSetupCompleted: boolean;
}

export interface SalaryCalculationResult {
  // Base inputs used
  basicSalary: number;
  workingDays: number;
  transportAllowance: number;
  foodAllowance: number;
  attendanceBonusConfig: number;
  otRate: number;

  // Attendance breakdown
  totalDaysInMonth: number;
  presentDays: number;
  absentDays: number;
  leaveDays: number;
  notMarkedDays: number;

  // Basic salary calculations
  dailyBasicSalary: number;
  basicDeduction: number;
  basicEarnedSalary: number;

  // Transport calculations
  dailyTransport: number;
  transportDeduction: number;
  transportEarned: number;

  // Food calculations
  dailyFood: number;
  foodDeduction: number;
  foodEarned: number;

  // Attendance bonus
  attendanceBonus: number;
  bonusForfeitedReason?: string;

  // Overtime calculations
  totalOtHours: number;
  otPay: number;

  // Deductions summary
  totalDeductions: number;

  // Final expected salary
  finalExpectedSalary: number;
}

export type NavigationTab = 'home' | 'calendar' | 'summary' | 'history' | 'settings';
