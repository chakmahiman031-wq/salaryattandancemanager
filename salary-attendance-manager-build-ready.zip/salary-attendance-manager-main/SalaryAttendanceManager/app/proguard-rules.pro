# ProGuard rules for Salary & Attendance Manager
-keep class com.salaryattendance.manager.data.model.** { *; }
