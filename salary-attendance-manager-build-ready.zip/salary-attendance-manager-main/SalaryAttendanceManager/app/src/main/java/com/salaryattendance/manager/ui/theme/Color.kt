package com.salaryattendance.manager.ui.theme

import androidx.compose.ui.graphics.Color

val EmeraldPrimary = Color(0xFF059669)
val EmeraldDark = Color(0xFF065F46)
val EmeraldLight = Color(0xFFD1FAE5)

val GoldAccent = Color(0xFFD97706)
val PresentGreen = Color(0xFF10B981)
val AbsentRed = Color(0xFFEF4444)
val LeaveYellow = Color(0xFFF59E0B)
val NotMarkedGray = Color(0xFF9CA3AF)

val LightBackground = Color(0xFFF8FAFC)
val DarkBackground = Color(0xFF090D16)
