package com.salaryattendance.manager.data.db

import androidx.room.*
import com.salaryattendance.manager.data.model.MonthlySalarySettings
import kotlinx.coroutines.flow.Flow

@Dao
interface SalaryDao {
    @Query("SELECT * FROM monthly_salary_settings WHERE year = :year AND month = :month LIMIT 1")
    fun getSettingsFlow(year: Int, month: Int): Flow<MonthlySalarySettings?>

    @Query("SELECT * FROM monthly_salary_settings WHERE year = :year AND month = :month LIMIT 1")
    suspend fun getSettings(year: Int, month: Int): MonthlySalarySettings?

    @Query("SELECT * FROM monthly_salary_settings ORDER BY (year * 12 + month) DESC")
    fun getAllSettingsFlow(): Flow<List<MonthlySalarySettings>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(settings: MonthlySalarySettings)

    @Query("DELETE FROM monthly_salary_settings")
    suspend fun clearAll()
}
