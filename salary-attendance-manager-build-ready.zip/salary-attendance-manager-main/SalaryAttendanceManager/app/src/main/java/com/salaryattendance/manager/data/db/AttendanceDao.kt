package com.salaryattendance.manager.data.db

import androidx.room.*
import com.salaryattendance.manager.data.model.AttendanceRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface AttendanceDao {
    @Query("SELECT * FROM attendance_records WHERE year = :year AND month = :month")
    fun getAttendanceFlow(year: Int, month: Int): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance_records WHERE year = :year AND month = :month")
    suspend fun getAttendance(year: Int, month: Int): List<AttendanceRecord>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(record: AttendanceRecord)

    @Query("DELETE FROM attendance_records WHERE year = :year AND month = :month AND date = :date")
    suspend fun deleteForDate(year: Int, month: Int, date: Int)

    @Query("DELETE FROM attendance_records")
    suspend fun clearAll()
}
