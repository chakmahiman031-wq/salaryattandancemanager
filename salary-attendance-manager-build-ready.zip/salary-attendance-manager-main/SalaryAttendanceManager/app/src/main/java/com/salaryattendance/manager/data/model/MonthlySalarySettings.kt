package com.salaryattendance.manager.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "monthly_salary_settings")
data class MonthlySalarySettings(
    @PrimaryKey val id: String, // e.g. "settings_2026_9"
    val year: Int,
    val month: Int,
    val basicSalary: Double,
    val transportAllowance: Double,
    val foodAllowance: Double,
    val attendanceBonus: Double,
    val workingDays: Int,
    val otRate: Double,
    val deductTransportOnAbsent: Boolean,
    val deductFoodOnAbsent: Boolean,
    val leaveAffectsBonus: Boolean
)
