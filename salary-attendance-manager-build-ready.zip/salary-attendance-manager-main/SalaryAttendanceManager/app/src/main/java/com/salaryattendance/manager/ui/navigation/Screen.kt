package com.salaryattendance.manager.ui.navigation

sealed class Screen(val route: String, val titleRes: Int) {
    object Home : Screen("home", com.salaryattendance.manager.R.string.nav_home)
    object Calendar : Screen("calendar", com.salaryattendance.manager.R.string.nav_calendar)
    object Summary : Screen("summary", com.salaryattendance.manager.R.string.nav_summary)
    object History : Screen("history", com.salaryattendance.manager.R.string.nav_history)
    object Settings : Screen("settings", com.salaryattendance.manager.R.string.nav_settings)
    object Setup : Screen("setup", com.salaryattendance.manager.R.string.app_name)
}
