package com.salaryattendance.manager.data.repository

import com.salaryattendance.manager.data.db.AttendanceDao
import com.salaryattendance.manager.data.db.DailyOTDao
import com.salaryattendance.manager.data.db.SalaryDao
import com.salaryattendance.manager.data.db.UserSettingsDao
import com.salaryattendance.manager.data.model.AttendanceRecord
import com.salaryattendance.manager.data.model.AttendanceStatus
import com.salaryattendance.manager.data.model.DailyOTRecord
import com.salaryattendance.manager.data.model.MonthlySalarySettings
import com.salaryattendance.manager.data.model.UserSettings
import kotlinx.coroutines.flow.Flow

class SalaryRepository(
    private val salaryDao: SalaryDao,
    private val attendanceDao: AttendanceDao,
    private val dailyOTDao: DailyOTDao,
    private val userSettingsDao: UserSettingsDao
) {
    fun getSalarySettingsFlow(year: Int, month: Int): Flow<MonthlySalarySettings?> =
        salaryDao.getSettingsFlow(year, month)

    suspend fun getSalarySettings(year: Int, month: Int): MonthlySalarySettings? =
        salaryDao.getSettings(year, month)

    suspend fun saveSalarySettings(settings: MonthlySalarySettings) =
        salaryDao.insertOrUpdate(settings)

    fun getAttendanceFlow(year: Int, month: Int): Flow<List<AttendanceRecord>> =
        attendanceDao.getAttendanceFlow(year, month)

    suspend fun setAttendance(year: Int, month: Int, date: Int, status: AttendanceStatus) {
        if (status == AttendanceStatus.NOT_MARKED) {
            attendanceDao.deleteForDate(year, month, date)
        } else {
            attendanceDao.insertOrUpdate(
                AttendanceRecord("att_${year}_${month}_${date}", year, month, date, status)
            )
        }
    }

    fun getOTFlow(year: Int, month: Int): Flow<List<DailyOTRecord>> =
        dailyOTDao.getOTFlow(year, month)

    suspend fun setDailyOT(year: Int, month: Int, date: Int, otHours: Double) {
        if (otHours <= 0.0) {
            dailyOTDao.deleteForDate(year, month, date)
        } else {
            dailyOTDao.insertOrUpdate(
                DailyOTRecord("ot_${year}_${month}_${date}", year, month, date, otHours)
            )
        }
    }

    fun getUserSettingsFlow(): Flow<UserSettings?> = userSettingsDao.getUserSettingsFlow()

    suspend fun saveUserSettings(settings: UserSettings) =
        userSettingsDao.insertOrUpdate(settings)

    suspend fun resetAllData() {
        salaryDao.clearAll()
        attendanceDao.clearAll()
        dailyOTDao.clearAll()
        userSettingsDao.clearAll()
    }
}
