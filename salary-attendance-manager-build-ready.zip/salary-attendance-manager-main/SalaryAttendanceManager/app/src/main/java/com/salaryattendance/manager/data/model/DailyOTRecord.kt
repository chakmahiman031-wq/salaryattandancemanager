package com.salaryattendance.manager.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "daily_ot_records")
data class DailyOTRecord(
    @PrimaryKey val id: String, // e.g. "ot_2026_9_5"
    val year: Int,
    val month: Int,
    val date: Int,
    val otHours: Double
)
