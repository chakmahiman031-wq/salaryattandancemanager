package com.salaryattendance.manager.data.db

import androidx.room.*
import com.salaryattendance.manager.data.model.DailyOTRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface DailyOTDao {
    @Query("SELECT * FROM daily_ot_records WHERE year = :year AND month = :month")
    fun getOTFlow(year: Int, month: Int): Flow<List<DailyOTRecord>>

    @Query("SELECT * FROM daily_ot_records WHERE year = :year AND month = :month")
    suspend fun getOT(year: Int, month: Int): List<DailyOTRecord>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(record: DailyOTRecord)

    @Query("DELETE FROM daily_ot_records WHERE year = :year AND month = :month AND date = :date")
    suspend fun deleteForDate(year: Int, month: Int, date: Int)

    @Query("DELETE FROM daily_ot_records")
    suspend fun clearAll()
}
