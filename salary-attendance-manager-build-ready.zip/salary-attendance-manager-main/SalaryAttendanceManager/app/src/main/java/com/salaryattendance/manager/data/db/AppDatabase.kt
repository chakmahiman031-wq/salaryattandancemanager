package com.salaryattendance.manager.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.salaryattendance.manager.data.model.AttendanceRecord
import com.salaryattendance.manager.data.model.DailyOTRecord
import com.salaryattendance.manager.data.model.MonthlySalarySettings
import com.salaryattendance.manager.data.model.UserSettings

@Database(
    entities = [
        MonthlySalarySettings::class,
        AttendanceRecord::class,
        DailyOTRecord::class,
        UserSettings::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun salaryDao(): SalaryDao
    abstract fun attendanceDao(): AttendanceDao
    abstract fun dailyOTDao(): DailyOTDao
    abstract fun userSettingsDao(): UserSettingsDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "salary_attendance_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
