package com.salaryattendance.manager.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_settings")
data class UserSettings(
    @PrimaryKey val id: Int = 1,
    val language: String = "bn", // "bn" or "en"
    val theme: String = "system", // "system", "light", "dark"
    val currency: String = "৳",
    val reminderEnabled: Boolean = true,
    val reminderTime: String = "21:00",
    val isFirstTimeSetupCompleted: Boolean = false
)
