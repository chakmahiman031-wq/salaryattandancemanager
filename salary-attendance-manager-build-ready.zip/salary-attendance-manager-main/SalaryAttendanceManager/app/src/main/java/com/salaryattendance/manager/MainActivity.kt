package com.salaryattendance.manager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.salaryattendance.manager.ui.navigation.Screen
import com.salaryattendance.manager.ui.theme.SalaryAttendanceTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SalaryAttendanceTheme {
                val navController = rememberNavController()
                val currentRoute = remember { mutableStateOf(Screen.Home.route) }

                Scaffold(
                    bottomBar = {
                        NavigationBar {
                            val items = listOf(
                                Screen.Home to Icons.Default.Home,
                                Screen.Calendar to Icons.Default.DateRange,
                                Screen.Summary to Icons.Default.Assessment,
                                Screen.History to Icons.Default.History,
                                Screen.Settings to Icons.Default.Settings
                            )
                            items.forEach { (screen, icon) ->
                                NavigationBarItem(
                                    icon = { Icon(icon, contentDescription = stringResource(screen.titleRes)) },
                                    label = { Text(stringResource(screen.titleRes)) },
                                    selected = currentRoute.value == screen.route,
                                    onClick = {
                                        currentRoute.value = screen.route
                                        navController.navigate(screen.route) {
                                            popUpTo(navController.graph.startDestinationId) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    }
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = Screen.Home.route,
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable(Screen.Home.route) {
                            Text("Salary & Attendance Manager - Home Screen", modifier = Modifier.padding(innerPadding))
                        }
                        composable(Screen.Calendar.route) {
                            Text("Monthly Calendar", modifier = Modifier.padding(innerPadding))
                        }
                        composable(Screen.Summary.route) {
                            Text("Salary Summary", modifier = Modifier.padding(innerPadding))
                        }
                        composable(Screen.History.route) {
                            Text("Salary History", modifier = Modifier.padding(innerPadding))
                        }
                        composable(Screen.Settings.route) {
                            Text("Settings", modifier = Modifier.padding(innerPadding))
                        }
                    }
                }
            }
        }
    }
}
