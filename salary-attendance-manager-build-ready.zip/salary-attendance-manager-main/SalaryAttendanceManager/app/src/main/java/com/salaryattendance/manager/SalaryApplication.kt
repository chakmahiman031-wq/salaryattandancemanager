package com.salaryattendance.manager

import android.app.Application
import com.salaryattendance.manager.data.db.AppDatabase
import com.salaryattendance.manager.data.repository.SalaryRepository

class SalaryApplication : Application() {
    val database: AppDatabase by lazy { AppDatabase.getDatabase(this) }
    val repository: SalaryRepository by lazy { 
        SalaryRepository(
            salaryDao = database.salaryDao(),
            attendanceDao = database.attendanceDao(),
            dailyOTDao = database.dailyOTDao(),
            userSettingsDao = database.userSettingsDao()
        )
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    companion object {
        lateinit var instance: SalaryApplication
            private set
    }
}
