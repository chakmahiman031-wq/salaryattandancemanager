package com.salaryattendance.manager.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class AttendanceStatus {
    PRESENT,
    ABSENT,
    LEAVE,
    NOT_MARKED
}

@Entity(tableName = "attendance_records")
data class AttendanceRecord(
    @PrimaryKey val id: String, // e.g. "att_2026_9_5"
    val year: Int,
    val month: Int,
    val date: Int,
    val status: AttendanceStatus
)
