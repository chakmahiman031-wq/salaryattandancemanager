package com.salaryattendance.manager.calculation

import com.salaryattendance.manager.data.model.AttendanceRecord
import com.salaryattendance.manager.data.model.AttendanceStatus
import com.salaryattendance.manager.data.model.DailyOTRecord
import com.salaryattendance.manager.data.model.MonthlySalarySettings
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Calendar

data class SalaryCalculationResult(
    val basicSalary: Double,
    val workingDays: Int,
    val transportAllowance: Double,
    val foodAllowance: Double,
    val attendanceBonusConfig: Double,
    val otRate: Double,
    val totalDaysInMonth: Int,
    val presentDays: Int,
    val absentDays: Int,
    val leaveDays: Int,
    val notMarkedDays: Int,
    val dailyBasicSalary: Double,
    val basicDeduction: Double,
    val basicEarnedSalary: Double,
    val dailyTransport: Double,
    val transportDeduction: Double,
    val transportEarned: Double,
    val dailyFood: Double,
    val foodDeduction: Double,
    val foodEarned: Double,
    val attendanceBonus: Double,
    val totalOtHours: Double,
    val otPay: Double,
    val totalDeductions: Double,
    val finalExpectedSalary: Double
)

object SalaryCalculationEngine {

    fun round2(value: Double): Double {
        return BigDecimal.valueOf(value)
            .setScale(2, RoundingMode.HALF_UP)
            .toDouble()
    }

    fun getDaysInMonth(year: Int, month: Int): Int {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.YEAR, year)
        calendar.set(Calendar.MONTH, month - 1)
        return calendar.getActualMaximum(Calendar.DAY_OF_MONTH)
    }

    fun calculate(
        settings: MonthlySalarySettings,
        attendanceRecords: List<AttendanceRecord>,
        otRecords: List<DailyOTRecord>
    ): SalaryCalculationResult {
        val totalDaysInMonth = getDaysInMonth(settings.year, settings.month)
        val workingDays = maxOf(1, settings.workingDays)
        val basicSalary = maxOf(0.0, settings.basicSalary)
        val transportAllowance = maxOf(0.0, settings.transportAllowance)
        val foodAllowance = maxOf(0.0, settings.foodAllowance)
        val bonusConfig = maxOf(0.0, settings.attendanceBonus)
        val otRate = maxOf(0.0, settings.otRate)

        val attendanceMap = attendanceRecords.associateBy { it.date }
        var presentDays = 0
        var absentDays = 0
        var leaveDays = 0
        var markedDays = 0

        for (d in 1..totalDaysInMonth) {
            when (attendanceMap[d]?.status) {
                AttendanceStatus.PRESENT -> {
                    presentDays++
                    markedDays++
                }
                AttendanceStatus.ABSENT -> {
                    absentDays++
                    markedDays++
                }
                AttendanceStatus.LEAVE -> {
                    leaveDays++
                    markedDays++
                }
                else -> {}
            }
        }
        val notMarkedDays = totalDaysInMonth - markedDays

        // 1. Basic Salary
        val dailyBasicSalary = round2(basicSalary / workingDays)
        val basicDeduction = round2(absentDays * dailyBasicSalary)
        val basicEarnedSalary = maxOf(0.0, round2(basicSalary - basicDeduction))

        // 2. Attendance Bonus
        val attendanceBonus = if (settings.leaveAffectsBonus) {
            if (absentDays > 0 || leaveDays > 0) 0.0 else round2(bonusConfig)
        } else {
            if (absentDays > 0) 0.0 else round2(bonusConfig)
        }

        // 3. Transport Allowance
        val (dailyTransport, transportDeduction, transportEarned) = if (settings.deductTransportOnAbsent) {
            val daily = round2(transportAllowance / workingDays)
            val deduction = round2(absentDays * daily)
            val earned = maxOf(0.0, round2(transportAllowance - deduction))
            Triple(daily, deduction, earned)
        } else {
            Triple(0.0, 0.0, round2(transportAllowance))
        }

        // 4. Food Allowance
        val (dailyFood, foodDeduction, foodEarned) = if (settings.deductFoodOnAbsent) {
            val daily = round2(foodAllowance / workingDays)
            val deduction = round2(absentDays * daily)
            val earned = maxOf(0.0, round2(foodAllowance - deduction))
            Triple(daily, deduction, earned)
        } else {
            Triple(0.0, 0.0, round2(foodAllowance))
        }

        // 5. Overtime
        var totalOt = 0.0
        for (ot in otRecords) {
            if (ot.otHours > 0.0) {
                totalOt += ot.otHours
            }
        }
        val totalOtHours = round2(totalOt)
        val otPay = round2(totalOtHours * otRate)

        val totalDeductions = round2(basicDeduction + transportDeduction + foodDeduction)
        val finalExpectedSalary = round2(
            basicEarnedSalary + transportEarned + foodEarned + attendanceBonus + otPay
        )

        return SalaryCalculationResult(
            basicSalary = basicSalary,
            workingDays = workingDays,
            transportAllowance = transportAllowance,
            foodAllowance = foodAllowance,
            attendanceBonusConfig = bonusConfig,
            otRate = otRate,
            totalDaysInMonth = totalDaysInMonth,
            presentDays = presentDays,
            absentDays = absentDays,
            leaveDays = leaveDays,
            notMarkedDays = notMarkedDays,
            dailyBasicSalary = dailyBasicSalary,
            basicDeduction = basicDeduction,
            basicEarnedSalary = basicEarnedSalary,
            dailyTransport = dailyTransport,
            transportDeduction = transportDeduction,
            transportEarned = transportEarned,
            dailyFood = dailyFood,
            foodDeduction = foodDeduction,
            foodEarned = foodEarned,
            attendanceBonus = attendanceBonus,
            totalOtHours = totalOtHours,
            otPay = otPay,
            totalDeductions = totalDeductions,
            finalExpectedSalary = finalExpectedSalary
        )
    }
}
