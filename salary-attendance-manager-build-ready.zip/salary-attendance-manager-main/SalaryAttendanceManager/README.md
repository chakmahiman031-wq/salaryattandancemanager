# Salary & Attendance Manager (Android App)

A complete, production-ready Android application built with Kotlin, Jetpack Compose, Material 3, Room Database, and WorkManager.

## Features
- **Monthly Basic Salary & Deductions**: Automatically calculates daily basic rate and absent deductions.
- **Company Car/Transport Allowance**: Full or conditional absent-based deduction.
- **Monthly Food Allowance**: Full or conditional absent-based deduction.
- **Strict Attendance Bonus**: Full bonus on 0 absent days; ৳0 on absences; optional leave forfeits bonus rule.
- **Overtime (OT) System**: Record decimal OT hours per date with custom monthly OT rate.
- **Interactive Monthly Calendar**: Color-coded indicators (Present: Green, Absent: Red, Leave: Yellow, Not Marked: Gray).
- **Centralized Calculation Engine**: Shared mathematical precision across all screens.
- **Salary History**: Isolated historical monthly records.
- **Local Offline Persistence**: Room Database (no internet required).
- **Localization**: Full Bengali (বাংলা) and English support.
- **Daily Attendance Reminders**: Android WorkManager & Notification APIs.

## How to Open in Android Studio
1. Open Android Studio (Hedgehog, Iguana, Koala, or newer).
2. Click **File -> Open...** and select the `SalaryAttendanceManager` directory.
3. Allow Gradle to sync dependencies automatically.

## How to Build the APK
### Debug APK:
```bash
./gradlew assembleDebug
```
The APK will be generated at `app/build/outputs/apk/debug/app-debug.apk`.

### Release APK:
```bash
./gradlew assembleRelease
```

## How to Change the App Name
Open `app/src/main/res/values/strings.xml` and `app/src/main/res/values-bn/strings.xml` and edit the `app_name` string.

## How to Change the App Icon
Replace `ic_launcher_foreground.xml` and `ic_launcher_background.xml` in `app/src/main/res/drawable/`.
