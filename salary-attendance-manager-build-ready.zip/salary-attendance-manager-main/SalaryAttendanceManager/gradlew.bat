@rem
@rem Copyright 2015 the original author or authors.
@rem
@if "%DEBUG%" == "" @echo off
set DIRNAME=%~dp0
if "%DIRNAME%" == "" set DIRNAME=.
gradle\wrapper\gradle-wrapper.jar org.gradle.wrapper.GradleWrapperMain %*
