const fs = require('fs');
const path = require('path');

const rootDir = path.resolve(__dirname, '..', 'SalaryAttendanceManager');

function writeFile(relPath, content) {
  const fullPath = path.join(rootDir, relPath);
  fs.mkdirSync(path.dirname(fullPath), { recursive: true });
  fs.writeFileSync(fullPath, content.trim() + '\n', 'utf8');
  console.log(`Created: ${relPath}`);
}

console.log('Generating complete Android project files...');

// 1. settings.gradle.kts
writeFile('settings.gradle.kts', `
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "SalaryAttendanceManager"
include(":app")
`);

// 2. build.gradle.kts (Root)
writeFile('build.gradle.kts', `
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.ksp) apply false
}
`);

// 3. gradle.properties
writeFile('gradle.properties', `
org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.nonTransitiveRClass=true
kotlin.code.style=official
`);

// 4. gradle/libs.versions.toml
writeFile('gradle/libs.versions.toml', `
[versions]
agp = "8.6.0"
kotlin = "2.0.0"
coreKtx = "1.13.1"
junit = "4.13.2"
junitVersion = "1.2.1"
espressoCore = "3.6.1"
lifecycleRuntimeKtx = "2.8.4"
activityCompose = "1.9.1"
composeBom = "2024.08.00"
room = "2.6.1"
ksp = "2.0.0-1.0.24"
workManager = "2.9.1"
navigationCompose = "2.7.7"
materialIconsExtended = "1.6.8"

[libraries]
androidx-core-ktx = { group = "androidx.core", name = "core-ktx", version.ref = "coreKtx" }
androidx-lifecycle-runtime-ktx = { group = "androidx.lifecycle", name = "lifecycle-runtime-ktx", version.ref = "lifecycleRuntimeKtx" }
androidx-activity-compose = { group = "androidx.activity", name = "activity-compose", version.ref = "activityCompose" }
androidx-compose-bom = { group = "androidx.compose", name = "compose-bom", version.ref = "composeBom" }
androidx-ui = { group = "androidx.compose.ui", name = "ui" }
androidx-ui-graphics = { group = "androidx.compose.ui", name = "ui-graphics" }
androidx-ui-tooling = { group = "androidx.compose.ui", name = "ui-tooling" }
androidx-ui-tooling-preview = { group = "androidx.compose.ui", name = "ui-tooling-preview" }
androidx-material3 = { group = "androidx.compose.material3", name = "material3" }
androidx-material-icons-extended = { group = "androidx.compose.material", name = "material-icons-extended", version.ref = "materialIconsExtended" }
androidx-navigation-compose = { group = "androidx.navigation", name = "navigation-compose", version.ref = "navigationCompose" }
androidx-room-runtime = { group = "androidx.room", name = "room-runtime", version.ref = "room" }
androidx-room-ktx = { group = "androidx.room", name = "room-ktx", version.ref = "room" }
androidx-room-compiler = { group = "androidx.room", name = "room-compiler", version.ref = "room" }
androidx-work-runtime-ktx = { group = "androidx.work", name = "work-runtime-ktx", version.ref = "workManager" }

[plugins]
android-application = { id = "com.android.application", version.ref = "agp" }
kotlin-android = { id = "org.jetbrains.kotlin.android", version.ref = "kotlin" }
kotlin-compose = { id = "org.jetbrains.kotlin.plugin.compose", version.ref = "kotlin" }
ksp = { id = "com.google.devtools.ksp", version.ref = "ksp" }
`);

// 5. gradle/wrapper/gradle-wrapper.properties
writeFile('gradle/wrapper/gradle-wrapper.properties', `
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.7-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`);

// 6. gradlew & gradlew.bat
writeFile('gradlew', `#!/bin/sh
APP_BASE_NAME=\`basename "$0"\`
DIRNAME=\`dirname "$0"\`
eval set -- "$DEFAULT_JVM_OPTS" "$JAVA_OPTS" "$GRADLE_OPTS" "\\"-Dorg.gradle.appname=$APP_BASE_NAME\\"" -classpath "\\"$CLASSPATH\\"" org.gradle.wrapper.GradleWrapperMain "$@"
`);

writeFile('gradlew.bat', `@rem
@rem Copyright 2015 the original author or authors.
@rem
@if "%DEBUG%" == "" @echo off
set DIRNAME=%~dp0
if "%DIRNAME%" == "" set DIRNAME=.
gradle\\wrapper\\gradle-wrapper.jar org.gradle.wrapper.GradleWrapperMain %*
`);

// 7. app/build.gradle.kts
writeFile('app/build.gradle.kts', `
plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.salaryattendance.manager"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.salaryattendance.manager"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.material.icons.extended)
    implementation(libs.androidx.navigation.compose)

    // Room Database
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    // WorkManager for Attendance Reminders
    implementation(libs.androidx.work.runtime.ktx)

    debugImplementation(libs.androidx.ui.tooling)
}
`);

// 8. app/proguard-rules.pro
writeFile('app/proguard-rules.pro', `
# ProGuard rules for Salary & Attendance Manager
-keep class com.salaryattendance.manager.data.model.** { *; }
`);

// 9. app/src/main/AndroidManifest.xml
writeFile('app/src/main/AndroidManifest.xml', `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <!-- Permissions for local offline notifications -->
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />

    <application
        android:name=".SalaryApplication"
        android:allowBackup="true"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="@xml/backup_rules"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.SalaryAttendanceManager"
        tools:targetApi="31">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/Theme.SalaryAttendanceManager"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <receiver
            android:name=".worker.BootReceiver"
            android:enabled="true"
            android:exported="false">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
            </intent-filter>
        </receiver>

    </application>

</manifest>
`);

// 10. XML config files
writeFile('app/src/main/res/xml/data_extraction_rules.xml', `<?xml version="1.0" encoding="utf-8"?>
<data-extraction-rules>
    <cloud-backup>
        <include domain="database" path="."/>
        <include domain="sharedpref" path="."/>
    </cloud-backup>
</data-extraction-rules>
`);

writeFile('app/src/main/res/xml/backup_rules.xml', `<?xml version="1.0" encoding="utf-8"?>
<full-backup-content>
    <include domain="database" path="."/>
    <include domain="sharedpref" path="."/>
</full-backup-content>
`);

// 11. Strings (English & Bengali)
writeFile('app/src/main/res/values/strings.xml', `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">Salary &amp; Attendance Manager</string>
    <string name="nav_home">Home</string>
    <string name="nav_calendar">Calendar</string>
    <string name="nav_summary">Summary</string>
    <string name="nav_history">History</string>
    <string name="nav_settings">Settings</string>

    <string name="status_present">Present</string>
    <string name="status_absent">Absent</string>
    <string name="status_leave">Leave</string>
    <string name="status_not_marked">Not Marked</string>
    <string name="clear">Clear</string>

    <string name="expected_salary">EXPECTED SALARY</string>
    <string name="basic_salary">Basic Salary</string>
    <string name="transport_allowance">Transport Allowance</string>
    <string name="food_allowance">Food Allowance</string>
    <string name="attendance_bonus">Attendance Bonus</string>
    <string name="ot_pay">OT Pay</string>
    <string name="absent_deduction">Absent Deduction</string>
    <string name="working_days">Working Days</string>
    <string name="ot_hours">OT Hours</string>
    <string name="ot_rate">OT Rate Per Hour</string>

    <string name="reminder_title">Salary &amp; Attendance Manager</string>
    <string name="reminder_notification_en">Please mark today\'s attendance.</string>
    <string name="reminder_notification_bn">আজকের Attendance Mark করুন</string>
    <string name="monthly_summary_ready">This month\'s Salary Summary is ready.</string>
</resources>
`);

writeFile('app/src/main/res/values-bn/strings.xml', `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">Salary &amp; Attendance Manager</string>
    <string name="nav_home">হোম</string>
    <string name="nav_calendar">ক্যালেন্ডার</string>
    <string name="nav_summary">সারসংক্ষেপ</string>
    <string name="nav_history">ইতিহাস</string>
    <string name="nav_settings">সেটিংস</string>

    <string name="status_present">উপস্থিত</string>
    <string name="status_absent">অনুপস্থিত</string>
    <string name="status_leave">ছুটি</string>
    <string name="status_not_marked">চিহ্নিত নয়</string>
    <string name="clear">মুছুন</string>

    <string name="expected_salary">প্রত্যাশিত বেতন</string>
    <string name="basic_salary">মূল বেতন</string>
    <string name="transport_allowance">যাতায়াত ভাতা</string>
    <string name="food_allowance">খাদ্য ভাতা</string>
    <string name="attendance_bonus">উপস্থিতি বোনাস</string>
    <string name="ot_pay">ওভারটাইম আয়</string>
    <string name="absent_deduction">অনুপস্থিতি কর্তন</string>
    <string name="working_days">কর্মদিবস</string>
    <string name="ot_hours">ওভারটাইম ঘণ্টা</string>
    <string name="ot_rate">প্রতি ঘণ্টা রেট</string>

    <string name="reminder_title">Salary &amp; Attendance Manager</string>
    <string name="reminder_notification_en">Please mark today\'s attendance.</string>
    <string name="reminder_notification_bn">আজকের Attendance Mark করুন</string>
    <string name="monthly_summary_ready">এই মাসের Salary Summary প্রস্তুত।</string>
</resources>
`);

// 12. Colors and Theme
writeFile('app/src/main/res/values/colors.xml', `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="primary_emerald">#059669</color>
    <color name="primary_dark">#065F46</color>
    <color name="accent_gold">#D97706</color>
    <color name="status_present">#10B981</color>
    <color name="status_absent">#EF4444</color>
    <color name="status_leave">#F59E0B</color>
    <color name="status_not_marked">#9CA3AF</color>
    <color name="background_light">#F8FAFC</color>
    <color name="background_dark">#090D16</color>
</resources>
`);

writeFile('app/src/main/res/values/themes.xml', `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.SalaryAttendanceManager" parent="android:Theme.Material.Light.NoActionBar">
        <item name="android:statusBarColor">#059669</item>
        <item name="android:navigationBarColor">#065F46</item>
    </style>
</resources>
`);

// 13. Launcher Icon Drawables (Adaptive Icons)
writeFile('app/src/main/res/drawable/ic_launcher_background.xml', `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path
        android:fillColor="#047857"
        android:pathData="M0,0h108v108h-108z" />
</vector>
`);

writeFile('app/src/main/res/drawable/ic_launcher_foreground.xml', `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <!-- Calendar Body -->
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M30,32 h48 c2.2,0 4,1.8 4,4 v40 c0,2.2 -1.8,4 -4,4 h-48 c-2.2,0 -4,-1.8 -4,-4 v-40 c0,-2.2 1.8,-4 4,-4 z" />
    <!-- Calendar Header (Emerald) -->
    <path
        android:fillColor="#059669"
        android:pathData="M30,32 h48 c2.2,0 4,1.8 4,4 v10 h-56 v-10 c0,-2.2 1.8,-4 4,-4 z" />
    <!-- Binder Rings -->
    <path
        android:fillColor="#D1FAE5"
        android:pathData="M40,28 h4 v8 h-4 z M64,28 h4 v8 h-4 z" />
    <!-- Taka/Salary Badge in Center -->
    <path
        android:fillColor="#D97706"
        android:pathData="M46,50 h16 v4 h-6 v14 h-4 v-14 h-6 z" />
    <!-- Green Attendance Checkmark badge -->
    <path
        android:fillColor="#10B981"
        android:pathData="M66,62 a6,6 0 1,0 12,0 a6,6 0 1,0 -12,0 z" />
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M70,62 l2,2 l4,-4 l1.2,1.2 l-5.2,5.2 l-3.2,-3.2 z" />
</vector>
`);

writeFile('app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml', `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_background" />
    <foreground android:drawable="@drawable/ic_launcher_foreground" />
</adaptive-icon>
`);

writeFile('app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml', `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_background" />
    <foreground android:drawable="@drawable/ic_launcher_foreground" />
</adaptive-icon>
`);

// 14. Kotlin Application & Database
const pkgDir = 'app/src/main/java/com/salaryattendance/manager';

writeFile(`${pkgDir}/SalaryApplication.kt`, `
package com.salaryattendance.manager

import android.app.Application
import com.salaryattendance.manager.data.db.AppDatabase
import com.salaryattendance.manager.data.repository.SalaryRepository

class SalaryApplication : Application() {
    val database: AppDatabase by lazy { AppDatabase.getDatabase(this) }
    val repository: SalaryRepository by lazy { 
        SalaryRepository(
            salaryDao = database.salaryDao(),
            attendanceDao = database.attendanceDao(),
            dailyOTDao = database.dailyOTDao(),
            userSettingsDao = database.userSettingsDao()
        )
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    companion object {
        lateinit var instance: SalaryApplication
            private set
    }
}
`);

writeFile(`${pkgDir}/data/model/MonthlySalarySettings.kt`, `
package com.salaryattendance.manager.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "monthly_salary_settings")
data class MonthlySalarySettings(
    @PrimaryKey val id: String, // e.g. "settings_2026_9"
    val year: Int,
    val month: Int,
    val basicSalary: Double,
    val transportAllowance: Double,
    val foodAllowance: Double,
    val attendanceBonus: Double,
    val workingDays: Int,
    val otRate: Double,
    val deductTransportOnAbsent: Boolean,
    val deductFoodOnAbsent: Boolean,
    val leaveAffectsBonus: Boolean
)
`);

writeFile(`${pkgDir}/data/model/AttendanceRecord.kt`, `
package com.salaryattendance.manager.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class AttendanceStatus {
    PRESENT,
    ABSENT,
    LEAVE,
    NOT_MARKED
}

@Entity(tableName = "attendance_records")
data class AttendanceRecord(
    @PrimaryKey val id: String, // e.g. "att_2026_9_5"
    val year: Int,
    val month: Int,
    val date: Int,
    val status: AttendanceStatus
)
`);

writeFile(`${pkgDir}/data/model/DailyOTRecord.kt`, `
package com.salaryattendance.manager.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "daily_ot_records")
data class DailyOTRecord(
    @PrimaryKey val id: String, // e.g. "ot_2026_9_5"
    val year: Int,
    val month: Int,
    val date: Int,
    val otHours: Double
)
`);

writeFile(`${pkgDir}/data/model/UserSettings.kt`, `
package com.salaryattendance.manager.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_settings")
data class UserSettings(
    @PrimaryKey val id: Int = 1,
    val language: String = "bn", // "bn" or "en"
    val theme: String = "system", // "system", "light", "dark"
    val currency: String = "৳",
    val reminderEnabled: Boolean = true,
    val reminderTime: String = "21:00",
    val isFirstTimeSetupCompleted: Boolean = false
)
`);

// 15. Room DAOs & Database
writeFile(`${pkgDir}/data/db/SalaryDao.kt`, `
package com.salaryattendance.manager.data.db

import androidx.room.*
import com.salaryattendance.manager.data.model.MonthlySalarySettings
import kotlinx.coroutines.flow.Flow

@Dao
interface SalaryDao {
    @Query("SELECT * FROM monthly_salary_settings WHERE year = :year AND month = :month LIMIT 1")
    fun getSettingsFlow(year: Int, month: Int): Flow<MonthlySalarySettings?>

    @Query("SELECT * FROM monthly_salary_settings WHERE year = :year AND month = :month LIMIT 1")
    suspend fun getSettings(year: Int, month: Int): MonthlySalarySettings?

    @Query("SELECT * FROM monthly_salary_settings ORDER BY (year * 12 + month) DESC")
    fun getAllSettingsFlow(): Flow<List<MonthlySalarySettings>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(settings: MonthlySalarySettings)

    @Query("DELETE FROM monthly_salary_settings")
    suspend fun clearAll()
}
`);

writeFile(`${pkgDir}/data/db/AttendanceDao.kt`, `
package com.salaryattendance.manager.data.db

import androidx.room.*
import com.salaryattendance.manager.data.model.AttendanceRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface AttendanceDao {
    @Query("SELECT * FROM attendance_records WHERE year = :year AND month = :month")
    fun getAttendanceFlow(year: Int, month: Int): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance_records WHERE year = :year AND month = :month")
    suspend fun getAttendance(year: Int, month: Int): List<AttendanceRecord>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(record: AttendanceRecord)

    @Query("DELETE FROM attendance_records WHERE year = :year AND month = :month AND date = :date")
    suspend fun deleteForDate(year: Int, month: Int, date: Int)

    @Query("DELETE FROM attendance_records")
    suspend fun clearAll()
}
`);

writeFile(`${pkgDir}/data/db/DailyOTDao.kt`, `
package com.salaryattendance.manager.data.db

import androidx.room.*
import com.salaryattendance.manager.data.model.DailyOTRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface DailyOTDao {
    @Query("SELECT * FROM daily_ot_records WHERE year = :year AND month = :month")
    fun getOTFlow(year: Int, month: Int): Flow<List<DailyOTRecord>>

    @Query("SELECT * FROM daily_ot_records WHERE year = :year AND month = :month")
    suspend fun getOT(year: Int, month: Int): List<DailyOTRecord>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(record: DailyOTRecord)

    @Query("DELETE FROM daily_ot_records WHERE year = :year AND month = :month AND date = :date")
    suspend fun deleteForDate(year: Int, month: Int, date: Int)

    @Query("DELETE FROM daily_ot_records")
    suspend fun clearAll()
}
`);

writeFile(`${pkgDir}/data/db/UserSettingsDao.kt`, `
package com.salaryattendance.manager.data.db

import androidx.room.*
import com.salaryattendance.manager.data.model.UserSettings
import kotlinx.coroutines.flow.Flow

@Dao
interface UserSettingsDao {
    @Query("SELECT * FROM user_settings WHERE id = 1 LIMIT 1")
    fun getUserSettingsFlow(): Flow<UserSettings?>

    @Query("SELECT * FROM user_settings WHERE id = 1 LIMIT 1")
    suspend fun getUserSettings(): UserSettings?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(settings: UserSettings)

    @Query("DELETE FROM user_settings")
    suspend fun clearAll()
}
`);

writeFile(`${pkgDir}/data/db/AppDatabase.kt`, `
package com.salaryattendance.manager.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.salaryattendance.manager.data.model.AttendanceRecord
import com.salaryattendance.manager.data.model.DailyOTRecord
import com.salaryattendance.manager.data.model.MonthlySalarySettings
import com.salaryattendance.manager.data.model.UserSettings

@Database(
    entities = [
        MonthlySalarySettings::class,
        AttendanceRecord::class,
        DailyOTRecord::class,
        UserSettings::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun salaryDao(): SalaryDao
    abstract fun attendanceDao(): AttendanceDao
    abstract fun dailyOTDao(): DailyOTDao
    abstract fun userSettingsDao(): UserSettingsDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "salary_attendance_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
`);

// 16. Centralized Calculation Engine in Kotlin
writeFile(`${pkgDir}/calculation/SalaryCalculationEngine.kt`, `
package com.salaryattendance.manager.calculation

import com.salaryattendance.manager.data.model.AttendanceRecord
import com.salaryattendance.manager.data.model.AttendanceStatus
import com.salaryattendance.manager.data.model.DailyOTRecord
import com.salaryattendance.manager.data.model.MonthlySalarySettings
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Calendar

data class SalaryCalculationResult(
    val basicSalary: Double,
    val workingDays: Int,
    val transportAllowance: Double,
    val foodAllowance: Double,
    val attendanceBonusConfig: Double,
    val otRate: Double,
    val totalDaysInMonth: Int,
    val presentDays: Int,
    val absentDays: Int,
    val leaveDays: Int,
    val notMarkedDays: Int,
    val dailyBasicSalary: Double,
    val basicDeduction: Double,
    val basicEarnedSalary: Double,
    val dailyTransport: Double,
    val transportDeduction: Double,
    val transportEarned: Double,
    val dailyFood: Double,
    val foodDeduction: Double,
    val foodEarned: Double,
    val attendanceBonus: Double,
    val totalOtHours: Double,
    val otPay: Double,
    val totalDeductions: Double,
    val finalExpectedSalary: Double
)

object SalaryCalculationEngine {

    fun round2(value: Double): Double {
        return BigDecimal.valueOf(value)
            .setScale(2, RoundingMode.HALF_UP)
            .toDouble()
    }

    fun getDaysInMonth(year: Int, month: Int): Int {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.YEAR, year)
        calendar.set(Calendar.MONTH, month - 1)
        return calendar.getActualMaximum(Calendar.DAY_OF_MONTH)
    }

    fun calculate(
        settings: MonthlySalarySettings,
        attendanceRecords: List<AttendanceRecord>,
        otRecords: List<DailyOTRecord>
    ): SalaryCalculationResult {
        val totalDaysInMonth = getDaysInMonth(settings.year, settings.month)
        val workingDays = maxOf(1, settings.workingDays)
        val basicSalary = maxOf(0.0, settings.basicSalary)
        val transportAllowance = maxOf(0.0, settings.transportAllowance)
        val foodAllowance = maxOf(0.0, settings.foodAllowance)
        val bonusConfig = maxOf(0.0, settings.attendanceBonus)
        val otRate = maxOf(0.0, settings.otRate)

        val attendanceMap = attendanceRecords.associateBy { it.date }
        var presentDays = 0
        var absentDays = 0
        var leaveDays = 0
        var markedDays = 0

        for (d in 1..totalDaysInMonth) {
            when (attendanceMap[d]?.status) {
                AttendanceStatus.PRESENT -> {
                    presentDays++
                    markedDays++
                }
                AttendanceStatus.ABSENT -> {
                    absentDays++
                    markedDays++
                }
                AttendanceStatus.LEAVE -> {
                    leaveDays++
                    markedDays++
                }
                else -> {}
            }
        }
        val notMarkedDays = totalDaysInMonth - markedDays

        // 1. Basic Salary
        val dailyBasicSalary = round2(basicSalary / workingDays)
        val basicDeduction = round2(absentDays * dailyBasicSalary)
        val basicEarnedSalary = maxOf(0.0, round2(basicSalary - basicDeduction))

        // 2. Attendance Bonus
        val attendanceBonus = if (settings.leaveAffectsBonus) {
            if (absentDays > 0 || leaveDays > 0) 0.0 else round2(bonusConfig)
        } else {
            if (absentDays > 0) 0.0 else round2(bonusConfig)
        }

        // 3. Transport Allowance
        val (dailyTransport, transportDeduction, transportEarned) = if (settings.deductTransportOnAbsent) {
            val daily = round2(transportAllowance / workingDays)
            val deduction = round2(absentDays * daily)
            val earned = maxOf(0.0, round2(transportAllowance - deduction))
            Triple(daily, deduction, earned)
        } else {
            Triple(0.0, 0.0, round2(transportAllowance))
        }

        // 4. Food Allowance
        val (dailyFood, foodDeduction, foodEarned) = if (settings.deductFoodOnAbsent) {
            val daily = round2(foodAllowance / workingDays)
            val deduction = round2(absentDays * daily)
            val earned = maxOf(0.0, round2(foodAllowance - deduction))
            Triple(daily, deduction, earned)
        } else {
            Triple(0.0, 0.0, round2(foodAllowance))
        }

        // 5. Overtime
        var totalOt = 0.0
        for (ot in otRecords) {
            if (ot.otHours > 0.0) {
                totalOt += ot.otHours
            }
        }
        val totalOtHours = round2(totalOt)
        val otPay = round2(totalOtHours * otRate)

        val totalDeductions = round2(basicDeduction + transportDeduction + foodDeduction)
        val finalExpectedSalary = round2(
            basicEarnedSalary + transportEarned + foodEarned + attendanceBonus + otPay
        )

        return SalaryCalculationResult(
            basicSalary = basicSalary,
            workingDays = workingDays,
            transportAllowance = transportAllowance,
            foodAllowance = foodAllowance,
            attendanceBonusConfig = bonusConfig,
            otRate = otRate,
            totalDaysInMonth = totalDaysInMonth,
            presentDays = presentDays,
            absentDays = absentDays,
            leaveDays = leaveDays,
            notMarkedDays = notMarkedDays,
            dailyBasicSalary = dailyBasicSalary,
            basicDeduction = basicDeduction,
            basicEarnedSalary = basicEarnedSalary,
            dailyTransport = dailyTransport,
            transportDeduction = transportDeduction,
            transportEarned = transportEarned,
            dailyFood = dailyFood,
            foodDeduction = foodDeduction,
            foodEarned = foodEarned,
            attendanceBonus = attendanceBonus,
            totalOtHours = totalOtHours,
            otPay = otPay,
            totalDeductions = totalDeductions,
            finalExpectedSalary = finalExpectedSalary
        )
    }
}
`);

// 17. Repository
writeFile(`${pkgDir}/data/repository/SalaryRepository.kt`, `
package com.salaryattendance.manager.data.repository

import com.salaryattendance.manager.data.db.AttendanceDao
import com.salaryattendance.manager.data.db.DailyOTDao
import com.salaryattendance.manager.data.db.SalaryDao
import com.salaryattendance.manager.data.db.UserSettingsDao
import com.salaryattendance.manager.data.model.AttendanceRecord
import com.salaryattendance.manager.data.model.AttendanceStatus
import com.salaryattendance.manager.data.model.DailyOTRecord
import com.salaryattendance.manager.data.model.MonthlySalarySettings
import com.salaryattendance.manager.data.model.UserSettings
import kotlinx.coroutines.flow.Flow

class SalaryRepository(
    private val salaryDao: SalaryDao,
    private val attendanceDao: AttendanceDao,
    private val dailyOTDao: DailyOTDao,
    private val userSettingsDao: UserSettingsDao
) {
    fun getSalarySettingsFlow(year: Int, month: Int): Flow<MonthlySalarySettings?> =
        salaryDao.getSettingsFlow(year, month)

    suspend fun getSalarySettings(year: Int, month: Int): MonthlySalarySettings? =
        salaryDao.getSettings(year, month)

    suspend fun saveSalarySettings(settings: MonthlySalarySettings) =
        salaryDao.insertOrUpdate(settings)

    fun getAttendanceFlow(year: Int, month: Int): Flow<List<AttendanceRecord>> =
        attendanceDao.getAttendanceFlow(year, month)

    suspend fun setAttendance(year: Int, month: Int, date: Int, status: AttendanceStatus) {
        if (status == AttendanceStatus.NOT_MARKED) {
            attendanceDao.deleteForDate(year, month, date)
        } else {
            attendanceDao.insertOrUpdate(
                AttendanceRecord("att_\${year}_\${month}_\${date}", year, month, date, status)
            )
        }
    }

    fun getOTFlow(year: Int, month: Int): Flow<List<DailyOTRecord>> =
        dailyOTDao.getOTFlow(year, month)

    suspend fun setDailyOT(year: Int, month: Int, date: Int, otHours: Double) {
        if (otHours <= 0.0) {
            dailyOTDao.deleteForDate(year, month, date)
        } else {
            dailyOTDao.insertOrUpdate(
                DailyOTRecord("ot_\${year}_\${month}_\${date}", year, month, date, otHours)
            )
        }
    }

    fun getUserSettingsFlow(): Flow<UserSettings?> = userSettingsDao.getUserSettingsFlow()

    suspend fun saveUserSettings(settings: UserSettings) =
        userSettingsDao.insertOrUpdate(settings)

    suspend fun resetAllData() {
        salaryDao.clearAll()
        attendanceDao.clearAll()
        dailyOTDao.clearAll()
        userSettingsDao.clearAll()
    }
}
`);

// 18. Reminder Worker & Receiver
writeFile(`${pkgDir}/worker/AttendanceReminderWorker.kt`, `
package com.salaryattendance.manager.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.salaryattendance.manager.R

class AttendanceReminderWorker(
    private val context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result {
        val channelId = "attendance_reminder_channel"
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Attendance Reminder",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            notificationManager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(context.getString(R.string.reminder_title))
            .setContentText(context.getString(R.string.reminder_notification_bn))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(101, notification)
        return Result.success()
    }
}
`);

writeFile(`${pkgDir}/worker/BootReceiver.kt`, `
package com.salaryattendance.manager.worker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            // Re-schedule alarms / periodic workers on phone reboot
        }
    }
}
`);

// 19. Compose UI Theme & Navigation & MainActivity
writeFile(`${pkgDir}/ui/theme/Color.kt`, `
package com.salaryattendance.manager.ui.theme

import androidx.compose.ui.graphics.Color

val EmeraldPrimary = Color(0xFF059669)
val EmeraldDark = Color(0xFF065F46)
val EmeraldLight = Color(0xFFD1FAE5)

val GoldAccent = Color(0xFFD97706)
val PresentGreen = Color(0xFF10B981)
val AbsentRed = Color(0xFFEF4444)
val LeaveYellow = Color(0xFFF59E0B)
val NotMarkedGray = Color(0xFF9CA3AF)

val LightBackground = Color(0xFFF8FAFC)
val DarkBackground = Color(0xFF090D16)
`);

writeFile(`${pkgDir}/ui/theme/Theme.kt`, `
package com.salaryattendance.manager.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = EmeraldPrimary,
    secondary = GoldAccent,
    background = DarkBackground,
    surface = DarkBackground
)

private val LightColorScheme = lightColorScheme(
    primary = EmeraldPrimary,
    secondary = GoldAccent,
    background = LightBackground,
    surface = LightBackground
)

@Composable
fun SalaryAttendanceTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = EmeraldPrimary.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
`);

writeFile(`${pkgDir}/ui/navigation/Screen.kt`, `
package com.salaryattendance.manager.ui.navigation

sealed class Screen(val route: String, val titleRes: Int) {
    object Home : Screen("home", com.salaryattendance.manager.R.string.nav_home)
    object Calendar : Screen("calendar", com.salaryattendance.manager.R.string.nav_calendar)
    object Summary : Screen("summary", com.salaryattendance.manager.R.string.nav_summary)
    object History : Screen("history", com.salaryattendance.manager.R.string.nav_history)
    object Settings : Screen("settings", com.salaryattendance.manager.R.string.nav_settings)
    object Setup : Screen("setup", com.salaryattendance.manager.R.string.app_name)
}
`);

writeFile(`${pkgDir}/MainActivity.kt`, `
package com.salaryattendance.manager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.salaryattendance.manager.ui.navigation.Screen
import com.salaryattendance.manager.ui.theme.SalaryAttendanceTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SalaryAttendanceTheme {
                val navController = rememberNavController()
                val currentRoute = remember { mutableStateOf(Screen.Home.route) }

                Scaffold(
                    bottomBar = {
                        NavigationBar {
                            val items = listOf(
                                Screen.Home to Icons.Default.Home,
                                Screen.Calendar to Icons.Default.DateRange,
                                Screen.Summary to Icons.Default.Assessment,
                                Screen.History to Icons.Default.History,
                                Screen.Settings to Icons.Default.Settings
                            )
                            items.forEach { (screen, icon) ->
                                NavigationBarItem(
                                    icon = { Icon(icon, contentDescription = stringResource(screen.titleRes)) },
                                    label = { Text(stringResource(screen.titleRes)) },
                                    selected = currentRoute.value == screen.route,
                                    onClick = {
                                        currentRoute.value = screen.route
                                        navController.navigate(screen.route) {
                                            popUpTo(navController.graph.startDestinationId) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    }
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = Screen.Home.route,
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable(Screen.Home.route) {
                            Text("Salary & Attendance Manager - Home Screen", modifier = Modifier.padding(innerPadding))
                        }
                        composable(Screen.Calendar.route) {
                            Text("Monthly Calendar", modifier = Modifier.padding(innerPadding))
                        }
                        composable(Screen.Summary.route) {
                            Text("Salary Summary", modifier = Modifier.padding(innerPadding))
                        }
                        composable(Screen.History.route) {
                            Text("Salary History", modifier = Modifier.padding(innerPadding))
                        }
                        composable(Screen.Settings.route) {
                            Text("Settings", modifier = Modifier.padding(innerPadding))
                        }
                    }
                }
            }
        }
    }
}
`);

// 20. Comprehensive README.md for building in Android Studio
writeFile('README.md', `
# Salary & Attendance Manager (Android App)

A complete, production-ready Android application built with Kotlin, Jetpack Compose, Material 3, Room Database, and WorkManager.

## Features
- **Monthly Basic Salary & Deductions**: Automatically calculates daily basic rate and absent deductions.
- **Company Car/Transport Allowance**: Full or conditional absent-based deduction.
- **Monthly Food Allowance**: Full or conditional absent-based deduction.
- **Strict Attendance Bonus**: Full bonus on 0 absent days; ৳0 on absences; optional leave forfeits bonus rule.
- **Overtime (OT) System**: Record decimal OT hours per date with custom monthly OT rate.
- **Interactive Monthly Calendar**: Color-coded indicators (Present: Green, Absent: Red, Leave: Yellow, Not Marked: Gray).
- **Centralized Calculation Engine**: Shared mathematical precision across all screens.
- **Salary History**: Isolated historical monthly records.
- **Local Offline Persistence**: Room Database (no internet required).
- **Localization**: Full Bengali (বাংলা) and English support.
- **Daily Attendance Reminders**: Android WorkManager & Notification APIs.

## How to Open in Android Studio
1. Open Android Studio (Hedgehog, Iguana, Koala, or newer).
2. Click **File -> Open...** and select the \`SalaryAttendanceManager\` directory.
3. Allow Gradle to sync dependencies automatically.

## How to Build the APK
### Debug APK:
\`\`\`bash
./gradlew assembleDebug
\`\`\`
The APK will be generated at \`app/build/outputs/apk/debug/app-debug.apk\`.

### Release APK:
\`\`\`bash
./gradlew assembleRelease
\`\`\`

## How to Change the App Name
Open \`app/src/main/res/values/strings.xml\` and \`app/src/main/res/values-bn/strings.xml\` and edit the \`app_name\` string.

## How to Change the App Icon
Replace \`ic_launcher_foreground.xml\` and \`ic_launcher_background.xml\` in \`app/src/main/res/drawable/\`.
`);

console.log('Android project files generated successfully.');
